package a.b.c.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import a.b.c.model.MemberBean;

@Controller
public class LoginController {
	@PostMapping("/Join")
	public String Join(@ModelAttribute MemberBean mbean) {
		return "Login";
	}
	@GetMapping("/Join")
	public String Join1(@ModelAttribute MemberBean mbean) {
		return "Login";
	}
	

}
