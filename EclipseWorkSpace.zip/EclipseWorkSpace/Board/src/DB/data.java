package DB;

import java.util.Iterator;
import java.util.Vector;

public class data {
	// 글번호 글 작성자 저장할 객체
	Vector<String> v = new Vector<>();
	// 글 제목을 저장할 객체
	Vector<String> s = new Vector<>();
	// 글 내용을 저장할 객체
	Vector<String> com = new Vector<>();

	// 객체에 하나의 글을 저장하는 메서드
	public void save(Bean b) {

		v.add(b.getWriter()); // 작성자

		s.add(b.getSubject()); // 제목

		com.add(b.getContent()); // 내용

	}

	// 글 목록을 보여주는 메서드
	public void List() {
		for (int i = 0; i < v.size(); i++) {
			System.out.println(
					"글 번호 : " + (i + 1) + " 글 제목 : " + s.get(i) + " 작성자 : " + v.get(i) + "글 내용 : " + com.get(i));
		}

	}

	// 내용 수정 글 선택
	public void myReplace(int num) {
		System.out.println(num + "번 글의 내용 : " + com.get(num - 1).toString());
	}

	// 내용 수정 글 받아와서 변경
	public void ReplaceContent(String str, int num) {
		com.set(num - 1, str);

	}

	// 제목 수정 글 받아와서 변경
	public void ReplaceSubject(String str, int num) {
		s.set(num - 1, str);

	}

	// 글 내용을 보여주는 메서드
	public void myContent(int num) {
		System.out.println(num + "번 글의 내용 : " + com.get(num - 1).toString());

	}

	// 글을 삭제해주는 메서드
	public void myDelete(int num) {
		v.remove(num - 1);
		s.remove(num - 1);
		com.remove(num - 1);
		System.out.println(num + " 번 글이 삭제 되었습니다");
	}

}
