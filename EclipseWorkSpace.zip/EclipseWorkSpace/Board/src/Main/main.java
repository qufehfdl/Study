package Main;

import Display.Banner;
import Service.start;

public class main {

	public static void main(String[] args) {
		Banner.banner("1");

		start.start();

	} 

}
