package Service;

import java.util.Scanner;

import DB.Bean;
import DB.data;

public class start {

	public static void start() {

		data d = new data();
		Bean bean = new Bean();

		out: while (true) {
			int num = 0;
			System.out.println("1.글목록 | 2.글쓰기 | 3.글내용 보기 | 4.글삭제 | 5.수정 | 6.종료");
			Scanner sc = new Scanner(System.in);
			String str = sc.nextLine();
			if (str.equals("1") || str.equals("2") || str.equals("3") || str.equals("4") || str.equals("5") || str.equals("6")) {
				num = Integer.parseInt(str);
			} else {
				System.out.println("다시 입력해 주세요");
				continue;
			}

			switch (num) {
			case 1:
				System.out.println("★글 목록");
				d.List();
				break;
			case 2:
				System.out.println("★글 쓰기");
				bean.setSubject(insert.insertSubject());
				bean.setWriter(insert.insertWriter());
				bean.setContent(insert.insertContent());
				d.save(bean);
				break;
			case 3:
				System.out.println("★글 번호를 입력해 주세요");
				sc = new Scanner(System.in);
				num = sc.nextInt();
				d.myContent(num);
				break;
			case 4:
				System.out.println("★글 번호를 입력해 주세요");
				sc = new Scanner(System.in);
				num = sc.nextInt();
				d.myDelete(num);
				break;
			case 5:
				System.out.println("1.내용 수정 2.제목 수정");
				sc = new Scanner(System.in);
				num = sc.nextInt();
				if (num == 1) {
					d.List();
					System.out.println("★글 번호를 입력해 주세요");
					sc = new Scanner(System.in);
					num = sc.nextInt();
					d.myReplace(num);

					System.out.println("내용을 입력해 주세요");
					Scanner sc1 = new Scanner(System.in);
					String replace = sc1.nextLine();
					bean.setContent(replace);
					d.ReplaceContent(replace, num);
				}
				if (num == 2) {
					d.List();
					System.out.println("★글 번호를 입력해 주세요");
					sc = new Scanner(System.in);
					num = sc.nextInt();
					d.myReplace(num);

					System.out.println("제목을 입력해 주세요");
					Scanner sc1 = new Scanner(System.in);
					String replace = sc1.nextLine();
					bean.setSubject(replace);
					d.ReplaceSubject(replace, num);
				}
				break;

			case 6:
				System.out.println("★종료");
				if (num == 6) {
					break out;
				}
			}
		}

	}
}
