package Basic._1Scanner;

import java.util.Scanner;

public class scanner {

	public static void main(String[] args) {
//			Scanner sc = new Scanner(System.in);
//			
//			int num = sc.nextInt(); //화면에서 입력받은 정수를 num에 저장
//			
//			String input = sc.nextLine(); //화면에서 입력받은 내용을 input에 저장
//			
//			int StrNum = Integer.parseInt(input); //input을 숫자로 변환 
	
	
	
	
	
	
	
	
	
	
	}
}
