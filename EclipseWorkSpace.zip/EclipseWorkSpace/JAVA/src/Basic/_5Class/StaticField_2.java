package Basic._5Class;

/*정적필드의 공유기능*/

class SS {
	int m=3; //인스턴스 필드
	static int n=5; //정적(static) 필드
}
public class StaticField_2 {
	public static void main(String[] args) {		
		SS a1 = new SS();
		SS a2 = new SS();
		
		//인스턴스 필드
		a1.m=5;
		a2.m=6; 		
		System.out.println(a1.m); //5
		System.out.println(a2.m); //6
		
		//정적필드
		a1.n=7;
		a2.n=8;		
		System.out.println(a1.n); //8
		System.out.println(a2.n); //8
		
		SS.n=9;
		System.out.println(a1.n); //9
		System.out.println(a2.n); //9
	}
}
