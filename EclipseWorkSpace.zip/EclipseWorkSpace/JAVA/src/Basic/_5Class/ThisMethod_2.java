package Basic._5Class;

/*this(생성자 매개변수) 활용*/

class AB{
	int m1, m2, m3, m4;
	AB() {
		m1 = 1;
		m2 = 2;
		m3 = 3;
		m4 = 4;
	}
	AB(int a) {
		m1 = a;
		m2 = 2;
		m3 = 3;
		m4 = 4;
	}
	AB(int a, int b) {
		m1 = a;
		m2 = b;
		m3 = 3;
		m4 = 4;
	}
	void print() {
		System.out.print(m1+" ");
		System.out.print(m2+" ");
		System.out.print(m3+" ");
		System.out.print(m4);	
		System.out.println();
	}	
}
class BBB {
	int m1, m2, m3, m4;
	BBB() {
		m1 = 1;
		m2 = 2;
		m3 = 3;
		m4 = 4;
	}
	BBB(int a) {
		this();
		m1 = a;
	}
	BBB(int a, int b) {
		this(a);
		m2 = b;		
	}
	/* 첫번째 생성자 호출 + 두개의 코드 추가
	B(int a, int b) {
		this();
		m1 = a;
		m2 = b;
	}
	*/	
	void print() {
		System.out.print(m1+" ");
		System.out.print(m2+" ");
		System.out.print(m3+" ");
		System.out.print(m4);	
		System.out.println();
	}	
}
public class ThisMethod_2 {
	public static void main(String[] args) {
		//#1. 세가지 객체 생성 (this() 미사용)
		AB a1 = new AB(); 
		AB a2 = new AB(10);
		AB a3 = new AB(10,20);		
		a1.print();
		a2.print();
		a3.print();
		
		System.out.println();
		
		//#2. 세가지 객체 생성 (this() 사용)
		BBB b1 = new BBB(); 
		BBB b2 = new BBB(10);
		BBB b3 = new BBB(10,20);		
		b1.print();
		b2.print();
		b3.print();
	}
}
