package 상속;

/*정적 메서드의 중복*/

class AA {
	static void print() {
		System.out.println("A 클래스");
	}
}

class BB extends AA {
	static void print() {
		System.out.println("B 클래스");
	}
}

public class OverlapStaticMethod {
	public static void main(String[] args) {
		// #1. 클래스 이름으로 바로 접근
		AA.print(); // A 클래스
		BB.print(); // B 클래스
		System.out.println();

		// #2. 객체 생성
		AA aa = new AA();
		BB bb = new BB();
		AA ab = new BB();

		// #3. 객체를 통한 메서드 호출
		aa.print(); // A 클래스
		bb.print(); // B 클래스
		ab.print(); // A 클래스
	}
}
