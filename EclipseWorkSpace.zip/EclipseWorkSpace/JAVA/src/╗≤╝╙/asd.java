package 상속;

import java.util.Vector;

//					student        <   studentTaehwa
//
//     Human   <	freeMan	
//					
//					worker
public class asd {
	public static void main(String[] args) {
		
		Human h1 = new Human(); // student의 데이터도 쓰고싶으면 h1은 다운캐스팅불가능
		Human h2 = new student(); // student의 데이터도 쓰고싶으면 h2는 다운캐스팅 가능

		student s = new student(); // 두 객체의 선언은 힙메모리에서 만들어지는 모양은 같지만
		Human h3 = new student(); // 가르키는 곳은 다르다

		// 가능한 다운캐스팅
		student s1 = (student) h3;

		// 불가능한 다운캐스팅 : 문법적으로는 에러가 안남
//			studentTaehwa s2 = (studentTaehwa)h1;

		System.out.println(s1.age);
		// System.out.println(s2.age); //실행 시 에러

		System.out.println("===============================================");
		// 다형성x
//		student z = new student();
//		freeMan x = new freeMan();
//		worker c = new worker();

		// 다형성o
		student z = new student();
		Human x = new freeMan();
		Human c = new worker();

		System.out.println("=================================================");

		Vector<Human> v = new Vector<>();
		v.add(z);
		v.add(x);
		v.add(c);
		for (Human human : v) {
			human.eat();
		}

	}
}
 
class Human {
	String name = "홍태화";
	int age = 32;

	public void eat() {
		System.out.println("먹다");
	}

	public void walk() {
		System.out.println("걷다");
	}
}

class student extends Human {
	int sNum = 1234; // 필드는 오버라이딩 안됨

	// 메서드 오버라이딩
	public void eat() {
		System.out.println("학생이 먹다");
	}

	public void study() {
		System.out.println("공부하다");
	}
}

class freeMan extends Human {
	int fNum = 0;

	// 메서드 오버라이딩
	public void eat() {
		System.out.println("백수가 먹다");
	}

	public void play() {
		System.out.println("놀다");
	}

}

class worker extends Human {
	int wNum = 5678;

	// 메서드 오버라이딩
	public void eat() {
		System.out.println("직장인이 먹다");
	}

	public void working() {
		System.out.println("일하다");
	}
}

class studentTaehwa extends student {
	int areaNum = 4;

	public void hardStudy() {
		System.out.println("열심히 공부하다");
	}
}
