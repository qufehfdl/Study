package 상속;

import java.util.TreeSet;

public class asdasd {

	public void lotto() {

		TreeSet<Integer> v = new TreeSet<>();
		while (v.size() < 6) {
			int num = (int) Math.floor(Math.random() * 45 + 1);
			v.add(num);
		}  
		System.out.println(v.toString());
	}  
 
	public static void main(String[] args) {
		asdasd a = new asdasd(); 
		a.lotto();
	}
}
