package Model;

import java.sql.*;
import java.util.*;
import javax.naming.*;
import javax.sql.*;

import oracle.net.aso.e;

public class MemberDAO {
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	// 커넥션 풀을 이용한 데이터 베이스 연결 메소드
	public void getCon() {
		try {
			// 외부에서 데이터를 읽어들여야 하기에
			Context initctx = new InitialContext();
			// 톰캣 서버에 정보를 담아놓은 곳으로 이동
			Context envctx = (Context) initctx.lookup("java:comp/env");
			// 데이터 소스 객체 선언
			DataSource ds = (DataSource) envctx.lookup("jdbc/pool");
			// 데이터 소스를 기준으로 커넥션을 연결
			con = ds.getConnection();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void insertMember(MemberBean bean) {
		try {
			getCon();

			String sql = "insert into TAEHWA.MEMBER values(?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getId());
			pstmt.setString(2, bean.getPw1());
			pstmt.setString(3, bean.getEmail());
			pstmt.setString(4, bean.getPhone());
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Vector<MemberBean> allMemberList() {
		Vector<MemberBean> v = new Vector<>();

		try {
			getCon();
			String sql = "select * from taehwa.member";
			// 쿼리실행시켜 주는 객체 생성
			pstmt = con.prepareStatement(sql);
			// 쿼리실행시킨 결과를 리턴해서 받아줌(오라클 테이블의 검색된 결과를 자바객체에 저장)
			rs = pstmt.executeQuery();

			while (rs.next()) { // 저장된 데이터만큼까지 반복문을 돌리겠다는 의미
				MemberBean bean = new MemberBean();
				bean.setId(rs.getString(1));
				bean.setPw1(rs.getString(2));
				bean.setEmail(rs.getString(3));
				bean.setPhone(rs.getString(4));
				// 패키징된 memberbean클래스의 변수 bean을 벡터에 저장
				v.add(bean); // 0번지부터 순서대로 데이터가 저장
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 다 저장된 벡터를 리턴
		return v;
	}

	public MemberBean MemberInfo(String id) {
		// 리턴타입은 한사람에 대한 정보만 리턴하기에 벡터안쓰고 빈클래스 객체 생성
		MemberBean bean = new MemberBean();

		try {
			getCon();
			String sql = "select * from taehwa.member where id=?";
			pstmt = con.prepareStatement(sql);
			// ?값을 맵핑
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) { // rs에 레코드가 있다면
				bean.setId(rs.getString(1));
				bean.setPw1(rs.getString(2));
				bean.setEmail(rs.getString(3));
				bean.setPhone(rs.getString(4));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	// 한사람의 패스워드값을 리턴하는 메서드
	public String getPass(String id) {
		// 스트링으로 리턴을 해야하므로 스트링 변수 선언
		String pass = "";

		try {
			getCon();
			String sql = "select pw1 from taehwa.member where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id); // 1번 물음표에 매개변수로받은 id값을 설정
			rs = pstmt.executeQuery();
			if (rs.next()) {
				pass = rs.getString(1); // 패스워드값이 저장된 컬럼 인덱스
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return pass;
	}
	
	//한 회원의 정보를 수정하는 메서드
	public void updateMember(MemberBean bean) {
		try {
			getCon();
			String sql = "update taehwa.member set email=?,phone=? where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getEmail());
			pstmt.setString(2, bean.getPhone());
			pstmt.setString(3, bean.getId());
			pstmt.executeUpdate();
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//회원탈퇴 메서드 작성
	public void deleteMember(String id) {
		try {
			getCon();
			String sql = "delete from taehwa.member where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.executeUpdate();
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
