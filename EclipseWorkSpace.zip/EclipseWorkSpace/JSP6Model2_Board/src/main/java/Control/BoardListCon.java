package Control;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.BoardBean;
import Model.BoardDAO;

@WebServlet("/BoardListCon.do")
//프로젝트 시작서블릿
public class BoardListCon extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response); 
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void reqPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//----------------카운터링 셋팅-----------------------
		// 화면에 보여질 게시글의 개수를 지정
		int pageSize = 10;
		// 현재 보여지고있는 페이지의 넘버값을 읽음
		String pageNum = request.getParameter("pageNum");
		// 널처리
		if (pageNum == null) {
			pageNum = "1";
		}
		// 전체 게시글의 개수를 파악
		int count = 0;
		// 페이지 내에서 보여질 글들의 번호를 설정
		int number = 0;
		// 현재 보여지고있는 페이지 문자를 숫자로 캐스팅
		int currentPage = Integer.parseInt(pageNum);
		// 전체 게시글의 개수를 가져와야해므로 데이터베이스 객체 생성
		BoardDAO bdao = new BoardDAO();
		count = bdao.getAllCount(); 

		// 현재 보여질 페이지 시작 번호를 설정
		int startRow = (currentPage - 1) * pageSize + 1;
		int endRow = currentPage * pageSize;

		// 최신글 10개를 기준으로 게시글을 리턴 받아주는 메서드 호출
		Vector<BoardBean> v = bdao.getAllBoard(startRow, endRow); // 스타트와 앤드를 넘겨줘야 그에 맞는 데이터만 받을수 있음
		number = count - (currentPage - 1) * pageSize; 
	  
	//----------------카운터링 셋팅 끝-------------------------
	 
	//수정 삭제시 비밀번호가 틀렸다면
		String msg = (String)request.getAttribute("msg");
		
	//BoardList.jsp쪽으로 request객체에 담아서 넘겨줌
	request.setAttribute("v", v);
	request.setAttribute("number", number);
	request.setAttribute("pageSize", pageSize);
	request.setAttribute("count", count);
	request.setAttribute("currentPage", currentPage);
	
	request.setAttribute("msg", msg);
	
	RequestDispatcher dis = request.getRequestDispatcher("BoardList.jsp");
	dis.forward(request, response);
	
	
	}    
} 
