package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDAO {

	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public void getCon() {
		try {
			// 커넥션 풀
			Context initctx = new InitialContext();
			Context envctx = (Context) initctx.lookup("java:comp/env");
			DataSource ds = (DataSource) envctx.lookup("jdbc/pool");
			con = ds.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ------------------------카운터링------------------------------
	public int getAllCount() {
		getCon();

		// 게시글 전체수를 저장하는 변수
		int count = 0;

		try {
			String sql = "select count(*) from taehwa.board";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				// 전체 게시글수 리턴
				count = rs.getInt(1);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}

	// 10개의 게시글을 리턴해주는 메서드
	public Vector<BoardBean> getAllBoard(int startRow, int endRow) {

		// 리턴할 객체 선언
		Vector<BoardBean> v = new Vector<>();
		getCon();
		try {
			String sql = "select * from (select A.*,Rownum Rnum from (select * from taehwa.board order by ref desc , re_step asc ,re_level)A)"
					+ "where Rnum>=? and Rnum<=?";
			// ◆먼저 모든게시글을 조회한값을 A로 설정하고 A의모든데이터와 Rnum을 같이 조회한 후 Rnum을 기준으로 데이터를 추출해서
			// select하시오
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			// 데이터 개수가 몇개인지 모르기에 반복문을 이용하여 데이터 추출
			while (rs.next()) {
				// 데이터를 패키징(가방=BoardBean클래스를 이용해서)
				BoardBean bean = new BoardBean();

				bean.setNum(rs.getInt(1));
				bean.setWriter(rs.getString(2));
				bean.setEmail(rs.getString(3));
				bean.setSubject(rs.getString(4));
				bean.setPassword(rs.getString(5));
				bean.setReg_date(rs.getDate(6).toString()); // 날짜형으로 받고 그다음 toStrig으로 문자형으로 변환
				bean.setRef(rs.getInt(7));
				bean.setRe_step(rs.getInt(8));
				bean.setRe_level(rs.getInt(9));
				bean.setReadcount(rs.getInt(10));
				bean.setContent(rs.getString(11));
				// 패키징한 데이터를 박스에 집어넣음
				v.add(bean);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;
	}
	// ------------------------카운터링 끝------------------------------

	// 하나의 게시글을 저장하는 메서드
	public void insertBoard(BoardBean bean) {
		getCon();
		int ref = 0;
		int re_step = 1; // 새글 이므로
		int re_level = 1; // 새글 이므로
		try {
			// 가장큰 글그룹을 ref에 저장
			String refsql = "select max(ref) from taehwa.board";
			pstmt = con.prepareStatement(refsql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ref = rs.getInt(1) + 1; // 가장 큰 값에 1을 더해줌
			}
			// 데이터를 넣는 쿼리 준비
			String sql = "insert into taehwa.board values(taehwa.board_seq.NEXTVAL,?,?,?,?,sysdate,?,?,?,0,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getWriter());
			pstmt.setString(2, bean.getEmail());
			pstmt.setString(3, bean.getSubject());
			pstmt.setString(4, bean.getPassword());
			pstmt.setInt(5, ref);
			pstmt.setInt(6, re_step);
			pstmt.setInt(7, re_level);
			pstmt.setString(8, bean.getContent());
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ---------------------------------------------------------------------------
	// 하나의 게시글을 BoardBean으로 리턴해주는 메서드
	public BoardBean getOneBoard(int num) {
		getCon();
		BoardBean bean = null;
		try {
			// 조회수 증가 쿼리
			String countsql = "update taehwa.board set readcount = readcount+1 where num=?";
			pstmt = con.prepareStatement(countsql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			// 한 게시글에 대한 정보를 리턴해주는 쿼리를 작성
			String sql = "select * from taehwa.board where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				bean = new BoardBean();
				bean.setNum(rs.getInt(1));
				bean.setWriter(rs.getString(2));
				bean.setEmail(rs.getString(3));
				bean.setSubject(rs.getString(4));
				bean.setPassword(rs.getString(5));
				bean.setReg_date(rs.getDate(6).toString()); // 날짜형으로 받고 그다음 toStrig으로 문자형으로 변환
				bean.setRef(rs.getInt(7));
				bean.setRe_step(rs.getInt(8));
				bean.setRe_level(rs.getInt(9));
				bean.setReadcount(rs.getInt(10));
				bean.setContent(rs.getString(11));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	// ---------------------------------------------------------------------------

	// 답변글을 저장하는 메서드
	public void reInsertBoard(BoardBean bean) {
		getCon();
		int ref = bean.getRef(); // 새글이 아니므로
		int re_step = bean.getRe_step(); // 새글이 아니므로
		int re_level = bean.getRe_level(); // 새글이 아니므로
		try {

			// ★★★ 핵심코드 ★★★ : 최신글이 먼저보여지게
			// 부모와 같은 글 그룹(ref)이면서 부모글레벨(re_level)보다 높은 다른 글들의 re_level을 1씩 증가시키는 쿼리
			String levelsql = "update taehwa.board set re_level= re_level+1 where ref=? and re_level>?";
			pstmt = con.prepareStatement(levelsql);
			pstmt.setInt(1, ref);
			pstmt.setInt(2, re_level);
			pstmt.executeUpdate();

			// 데이터를 넣는 쿼리 준비
			String sql = "insert into taehwa.board values(taehwa.board_seq.NEXTVAL,?,?,?,?,sysdate,?,?,?,0,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getWriter());
			pstmt.setString(2, bean.getEmail());
			pstmt.setString(3, bean.getSubject());
			pstmt.setString(4, bean.getPassword());
			pstmt.setInt(5, ref);
			pstmt.setInt(6, re_step + 1); // 내 글은 기존 부모글에 스탭보다 1 증가 시켜야함
			pstmt.setInt(7, re_level + 1); // 내 글은 기존 부모글에 스탭보다 1 증가 시켜야함
			pstmt.setString(8, bean.getContent());
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ---------------------------------------------------------------------------
	// 조회수가 증가하지않는 하나의 게시글을 리턴
	public BoardBean getOneUpdateBoard(int num) {
		getCon();
		BoardBean bean = new BoardBean();
		try {
			String sql = "select * from taehwa.board where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				bean.setNum(rs.getInt(1));
				bean.setWriter(rs.getString(2));
				bean.setEmail(rs.getString(3));
				bean.setSubject(rs.getString(4));
				bean.setPassword(rs.getString(5));
				bean.setReg_date(rs.getDate(6).toString()); // 날짜형으로 받고 그다음 toStrig으로 문자형으로 변환
				bean.setRef(rs.getInt(7));
				bean.setRe_step(rs.getInt(8));
				bean.setRe_level(rs.getInt(9));
				bean.setReadcount(rs.getInt(10));
				bean.setContent(rs.getString(11));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	// ---------------------------------------------------------------------------
	// 게시글을 수정하는 메서드

	public void updateBoard(int num ,String subject , String content) {
		getCon();
		try {
			String sql = "update taehwa.board set subject=? , content=? where num=? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, subject);
			pstmt.setString(2, content);
			pstmt.setInt(3, num);
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}}
	
	// ---------------------------------------------------------------------------
	//게시글을 삭제하는 메서드
	public void DeleteBoard(int num) {
		getCon();
		try {
			String sql = "delete from taehwa.board where num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			}
	}
}
