/**
 * 
 */
/**
 * @author hth19
 *
 */
module JavaMySqlConnection {
	requires java.sql;
}