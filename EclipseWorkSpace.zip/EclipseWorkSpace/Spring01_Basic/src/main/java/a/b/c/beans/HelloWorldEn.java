package a.b.c.beans;

public class HelloWorldEn implements HelloWorld{

	public void sayHello() {
		System.out.println("hi~");
	}
	
}
