package a.b.c.beans;

public class HelloWorldKo implements HelloWorld{

	public void sayHello() {
		System.out.println("안녕~");
	}
	
}
