package a.b.c.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.HelloWorld;

public class MainClass {

	public static void main(String[] args) {

		// 생성하는 순간 IoC컨테이너에 객체가 등록되어 콘솔에 TestBean()생성자가 호출된다
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");
		// xml에 정의한 bean객체의 주소값을 가지고옴
		// id가 hello로 지정되어있는 클래스를가지고 객체를만들어서 가져와라!!
		
		// 방법1
		HelloWorld hello1 = (HelloWorld) ctx.getBean("hello1"); // getBean()이 오브젝트타입으로 반환됨!! 캐스팅해주자
		// 방법2
		HelloWorld hello2 = ctx.getBean("hello2", HelloWorld.class);

		callMethod(hello1);
		callMethod(hello2);

		// IoC컨테이너 종료 : 객체도 소멸!
		ctx.close();
	}

	public static void callMethod(HelloWorld hello) {
		hello.sayHello();
	}
}
