package a.b.c.beans;

public class TestBean {
public TestBean() {
	System.out.println("테스트빈의 생성자");
}
}
