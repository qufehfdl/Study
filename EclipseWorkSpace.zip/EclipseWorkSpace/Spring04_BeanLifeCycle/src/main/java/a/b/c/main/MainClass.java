package a.b.c.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;
import a.b.c.beans.TestBean3;

public class MainClass {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");

		TestBean1 t1 = ctx.getBean("t1", TestBean1.class);
		System.out.println(t1);

		System.out.println("====================================");

		TestBean2 t2 = ctx.getBean("t2", TestBean2.class);
		System.out.println(t2);
		
		System.out.println("====================================");

		TestBean3 t3 = ctx.getBean("t3", TestBean3.class);
		System.out.println(t3);
		
		
		
		// 만약 ctx.close()를 작성하지 않으면 destroy-method는 동작하지 않는다
		ctx.close();
	}

}
