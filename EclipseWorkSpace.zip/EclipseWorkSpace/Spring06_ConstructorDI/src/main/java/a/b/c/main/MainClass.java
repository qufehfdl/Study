package a.b.c.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.TestBean;
import a.b.c.beans.TestBean2;

public class MainClass {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");

		TestBean t1 = new TestBean();
		t1.printData();

		System.out.println("------------------------------------------------");

		TestBean t2 = new TestBean(100);
		t2.printData();

		System.out.println("---------------요기까지는 자바코드만 사용한 것---------------");

		TestBean obj1 = ctx.getBean("obj1", TestBean.class);
		obj1.printData();

		System.out.println("------------------------------------------------");

		TestBean obj2 = ctx.getBean("obj2", TestBean.class);
		obj2.printData();

		System.out.println("------------------------------------------------");

		TestBean obj3 = ctx.getBean("obj3", TestBean.class);
		obj3.printData();

		System.out.println("------------------------------------------------");

		TestBean obj4 = ctx.getBean("obj4", TestBean.class);
		obj4.printData();

		System.out.println("------------------------------------------------");

		TestBean obj5 = ctx.getBean("obj5", TestBean.class);
		obj5.printData();

		System.out.println("------------------------------------------------");
		System.out.println("----------객체를 주입해 보자!!------------");

		TestBean2 obj6 = ctx.getBean("obj6", TestBean2.class);
		obj6.printData();

		System.out.println("------------------------------------------------");

		TestBean2 obj7 = ctx.getBean("obj7", TestBean2.class);
		obj7.printData();

		ctx.close();
	}

}
