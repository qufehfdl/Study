package a.b.c.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.TestBean;

public class MainClass {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");

		TestBean t1 = ctx.getBean("t1" , TestBean.class);
		System.out.println(t1.getData1());
		System.out.println(t1.getData2());
		//boolean 타입은 getData3() 이 아니라 isData3()
		System.out.println(t1.isData3());
		System.out.println(t1.getData4());
		System.out.println(t1.getData5());
		System.out.println(t1.getData6()); 
		
		
		 
		 
		
		
		
		
		ctx.close();
	}

}
