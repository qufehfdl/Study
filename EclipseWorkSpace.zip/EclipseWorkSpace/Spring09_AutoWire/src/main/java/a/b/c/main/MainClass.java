package a.b.c.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;

public class MainClass {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");

		//자동주입x
		TestBean1 obj1 = ctx.getBean("obj1",TestBean1.class);
		System.out.println(obj1.getData1());
		System.out.println(obj1.getData2());
		
		System.out.println("==================================================");
		
		//자동주입o        byName
		TestBean1 obj2 = ctx.getBean("obj2",TestBean1.class);
		System.out.println(obj2.getData1());
		System.out.println(obj2.getData2());
	
		System.out.println("==================================================");
		
		//자동주입o        byType
		TestBean2 obj3 = ctx.getBean("obj3",TestBean2.class);
		System.out.println(obj3.getData1());
		System.out.println(obj3.getData2()); 
		
		ctx.close();
	} 

} 
