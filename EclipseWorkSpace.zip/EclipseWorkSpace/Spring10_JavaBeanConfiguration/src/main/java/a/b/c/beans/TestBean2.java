package a.b.c.beans;

public class TestBean2 {
	
	public TestBean2() {
		System.out.println("TestBean2 생성자");
	}
}
