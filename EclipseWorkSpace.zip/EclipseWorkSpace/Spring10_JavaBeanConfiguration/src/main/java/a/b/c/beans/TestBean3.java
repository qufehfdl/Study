package a.b.c.beans;

public class TestBean3 {
	
	public TestBean3() {
		System.out.println("TestBean3 생성자");
	}
}
