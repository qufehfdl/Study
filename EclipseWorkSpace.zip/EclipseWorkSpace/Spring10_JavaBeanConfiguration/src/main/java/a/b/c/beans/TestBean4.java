package a.b.c.beans;

public class TestBean4 {
	
	public TestBean4() {
		System.out.println("TestBean4 생성자");
	}
}
