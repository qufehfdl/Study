package a.b.c.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;
import a.b.c.beans.TestBean3;
import a.b.c.beans.TestBean4;

//이 자바 파일이 beans.xml파일 역할을 하게 된다 xml파일이 없어도 됨
@Configuration
public class BeanConfigClass {
	
	//객체를 생성하고 반환하는 메서드를 만들어 주면 t1이 반환하는 주소값을 bean객체가 가지고 있게 됨
	@Bean		//메서드의 이름이 bean의 이름이 된다 즉 <bean id="이름" class="~~"></bean> 과 같다
	public TestBean1 java1() {
		TestBean1 t1 = new TestBean1();
		return t1;
	}
	
	//==============================================
	
	//name을 사용해서 bean의 이름을 바꿔주자
	@Bean(name = "java600")		
	public TestBean1 java100() {
		TestBean1 t1 = new TestBean1();
		return t1;
	}
	
	//==============================================
	
	@Bean
	@Lazy //컨테이너가 만들어질때 생성되지 않고 getBean()호출할 때 객체가 생성됨
	public TestBean2 java2() {
		TestBean2 t1 = new TestBean2();
		return t1;
	}
	
	//==============================================
	
	@Bean
	@Scope("prototype") //컨테이너가 만들어질때 생성되지 않고 getBean()호출할 때 [마다 새로운!!!!!] 객체가 생성됨
	public TestBean3 java3() {
		TestBean3 t1 = new TestBean3();
		return t1;
	}
	
	//==============================================
	
	@Bean
	public TestBean4 java4() {
		TestBean4 t1 = new TestBean4();
		return t1;
	}
	@Bean
	@Primary
	public TestBean4 java5() {
		TestBean4 t1 = new TestBean4();
		return t1;
	}
	
}
  