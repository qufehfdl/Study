package a.b.c.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;
import a.b.c.beans.TestBean3;
import a.b.c.beans.TestBean4;
import a.b.c.config.BeanConfigClass;

public class MainClass {

	public static void main(String[] args) {
//		xml 방식
//		ClassPathXmlApplicationContext ctx1 = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");
//		ctx1.close();

		System.out.println("======================================");

		// 자바파일 방식 beans.xml역할을 할 클래스 지정
		AnnotationConfigApplicationContext ctx2 = new AnnotationConfigApplicationContext(BeanConfigClass.class);
		System.out.println();

		// 싱글톤이라서 객체의 주소값은 t1,t2 둘다 같다
		TestBean1 t1 = ctx2.getBean("java1", TestBean1.class);
		System.out.println(t1);
		TestBean1 t2 = ctx2.getBean("java1", TestBean1.class);
		System.out.println(t2);

		System.out.println("========================================================");

		// @Bean(name="") 을 이용해 bean의 이름을 바꿔보자!
		TestBean1 t3 = ctx2.getBean("java600", TestBean1.class);
		System.out.println(t3);

		System.out.println("========================================================");

		// @Lazy를 사용해보자 싱글톤이기 때문에 getBean()호출 될 때 같은객체가 만들어짐
		TestBean2 t4 = ctx2.getBean("java2", TestBean2.class);
		System.out.println(t4);
		TestBean2 t5 = ctx2.getBean("java2", TestBean2.class);
		System.out.println(t5);

		System.out.println("========================================================");

		// @Scope를 사용해보자 프로토타입으로 설정하면 getBean()때 마다 새로운 객체가 생성
		TestBean3 t6 = ctx2.getBean("java3", TestBean3.class);
		System.out.println(t6);
		TestBean3 t7 = ctx2.getBean("java3", TestBean3.class);
		System.out.println(t7);
		
		System.out.println("========================================================");
		
		// @Primary를 사용해보자
		TestBean4 t8 = ctx2.getBean(TestBean4.class);
		System.out.println(t8);
		TestBean4 t9 = ctx2.getBean(TestBean4.class);
		System.out.println(t9);
		
		ctx2.close();

	}

}
