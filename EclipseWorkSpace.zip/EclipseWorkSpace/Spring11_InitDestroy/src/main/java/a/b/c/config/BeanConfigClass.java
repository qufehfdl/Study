package a.b.c.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import a.b.c.beans.TestBean1;

@Configuration
public class BeanConfigClass {
	
	//@Bean에 initMethod 속성 , destroyMethod 속성을 넣어주면 된다
	//값으로는 메서드 이름을 넣어주자
	@Bean(initMethod = "init" , destroyMethod = "destroy")
	@Lazy
	public TestBean1 java1() {
		return new TestBean1(); 
	}
	
	
}
