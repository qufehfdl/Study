package a.b.c.beans;

public class TestBean1 {
	private DataBean1 data1;

	public DataBean1 getData1() {
		return data1;
	}
	public void setData1(DataBean1 data1) {
		this.data1 = data1;
	}
	
	
	
}
