package a.b.c.beans2;

import org.springframework.stereotype.Component;

//Bean으로 등록한다
//이름이 없기 때문에 타입을 통해서 받아 낼 수 있다
@Component
public class TestBean3 {

}
