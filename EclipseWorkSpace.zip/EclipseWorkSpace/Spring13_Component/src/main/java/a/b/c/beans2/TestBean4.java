package a.b.c.beans2;

import org.springframework.stereotype.Component;

//이름등록
@Component("bean4")
public class TestBean4 {

}
