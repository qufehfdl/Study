package a.b.c.beans3;

import org.springframework.stereotype.Component;

//복수의 패키지
@Component
public class TestBean5 {

}
