package a.b.c.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;

@Configuration

//지정된 패키지의 bean클래스들의 어노테이션을 분석하여 bean을 등록하라고 지정한다
@ComponentScan(basePackages = "a.b.c.beans2")

//복수의 패키지도 스캔가능
@ComponentScan(basePackages = "a.b.c.beans3")
public class BeanConfigClass {

	// 타입으로 겟 빈
	@Bean
	public TestBean1 java1() {
		return new TestBean1();
	}

	// 이름을 사용해서 겟빈
	@Bean
	public TestBean2 java2() {
		return new TestBean2();
	}

	// 이름을 사용해서 겟빈
	@Bean
	public TestBean2 java3() {
		return new TestBean2();
	}
	// 여기까진 conponent안쓴것
	//================================================================
}
