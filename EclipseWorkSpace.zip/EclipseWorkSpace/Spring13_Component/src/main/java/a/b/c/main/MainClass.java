package a.b.c.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;
import a.b.c.beans2.TestBean3;
import a.b.c.beans2.TestBean4;
import a.b.c.beans3.TestBean5;
import a.b.c.config.BeanConfigClass;

public class MainClass {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(BeanConfigClass.class);

		// 타입으로 겟빈
		TestBean1 t1 = ctx.getBean(TestBean1.class);
		System.out.println(t1);

		// 메서드 이름으로 겟빈
		TestBean2 t2 = ctx.getBean("java2", TestBean2.class);
		System.out.println(t2);

		TestBean2 t3 = ctx.getBean("java3", TestBean2.class);
		System.out.println(t3);

		System.out.println("=====================================================");

		// component 사용 이름x
		TestBean3 t4 = ctx.getBean(TestBean3.class);
		System.out.println(t4);

		// component 사용 이름o
		TestBean4 t5 = ctx.getBean("bean4", TestBean4.class);
		System.out.println(t5);

		// 스캔할 페이지 또 있을때
		TestBean5 t6 = ctx.getBean(TestBean5.class);
		System.out.println(t6);

		ctx.close();
	}

}
