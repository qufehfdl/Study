package a.b.c.beans;

import org.springframework.stereotype.Component;

//IoC 컨테이너를 생성할 때 자동으로 객체가 생성됨
//Singleton 이다
//타입을 통해 등록된 Bean객체를 가져올 수 있다
@Component //붙여주면 bean으로 등록됨!
public class TestBean1 {
	public TestBean1() {
		System.out.println("TestBean1의 생성자");
	}
}
