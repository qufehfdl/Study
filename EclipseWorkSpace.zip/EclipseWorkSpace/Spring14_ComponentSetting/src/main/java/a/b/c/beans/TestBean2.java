package a.b.c.beans;

import org.springframework.stereotype.Component;

//IoC 컨테이너를 생성할 때 자동으로 객체가 생성됨
//Singleton 이다
//이름을 통해 등록된 Bean객체를 가져올 수 있다    :  ★의미는 별로없음 @Bean을 이용하자
@Component("t3") 
public class TestBean2 {
	public TestBean2() {
		System.out.println("TestBean2의 생성자");
	}
}
