package a.b.c.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;
import a.b.c.beans.TestBean3;
import a.b.c.beans.TestBean4;
import a.b.c.beans.TestBean5;
import a.b.c.config.BeanConfigClass;

public class MainClass {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(BeanConfigClass.class);

		// 싱글톤이기에 똑같은 객체임
		TestBean1 t1 = ctx.getBean(TestBean1.class);
		System.out.println("t1 : " + t1);

		TestBean1 t2 = ctx.getBean(TestBean1.class);
		System.out.println("t2 : " + t2);

		System.out.println("--------------------------------------------------");

		// 지정된 이름을 사용해서 가져옴 : 의미x
		TestBean2 t3 = ctx.getBean("t3", TestBean2.class);
		System.out.println("t3 : " + t3);

		TestBean2 t4 = ctx.getBean("t3", TestBean2.class);
		System.out.println("t4 : " + t4);

		System.out.println("--------------------------------------------------");

		// 똑같은 클래스타입으로 여러 bean을 만들어 사용하고싶다면 @Bean을 사용하자

		TestBean2 t5 = ctx.getBean("t5", TestBean2.class);
		System.out.println("t5 : " + t5);

		TestBean2 t6 = ctx.getBean("t6", TestBean2.class);
		System.out.println("t6 : " + t6);

		// @Lazy : getBean시 생성됨
		// singleton입니당
		TestBean3 t7 = ctx.getBean(TestBean3.class);
		System.out.println("t7 : " + t7);

		TestBean3 t8 = ctx.getBean(TestBean3.class);
		System.out.println("t8 : " + t8);

		// @Scope("prototype")
		TestBean4 t9 = ctx.getBean(TestBean4.class);
		System.out.println("t9 : " + t9);

		TestBean4 t10 = ctx.getBean(TestBean4.class);
		System.out.println("t10 : " + t10);
		
		//  @PostConstuct 와 @PreDestroy
		TestBean5 t11 = ctx.getBean(TestBean5.class);
		 

		ctx.close();
	}

}
