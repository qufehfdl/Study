package a.b.c.beans;

import org.springframework.stereotype.Component;

@Component("obj2")
public class DataBean2 {

}
