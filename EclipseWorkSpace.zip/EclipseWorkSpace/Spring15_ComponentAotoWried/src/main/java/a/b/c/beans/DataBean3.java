package a.b.c.beans;

import org.springframework.stereotype.Component;

@Component("obj3")
public class DataBean3 {

}
