package a.b.c.beans;

import org.springframework.stereotype.Component;

@Component
public class DataBean5 {

}
