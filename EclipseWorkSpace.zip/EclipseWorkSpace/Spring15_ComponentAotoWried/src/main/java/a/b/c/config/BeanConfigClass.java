package a.b.c.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import a.b.c.beans.DataBean3;
import a.b.c.beans.DataBean4;
import a.b.c.beans.DataBean5;
import a.b.c.beans.TestBean2;
import a.b.c.beans.TestBean3;

@Repository
@Configuration
@ComponentScan(basePackages = "a.b.c.beans")
public class BeanConfigClass {

	// 게터와 세터를 이용한 자동 주입
	@Bean
	public DataBean3 obj4() {
		return new DataBean3();
	}

	@Bean
	public DataBean3 obj5() {
		return new DataBean3();
	}

	// =========================================================

	// 생성자를 이용한 자동 주입 방법2
	@Bean
	public TestBean3 java1() {
		TestBean3 t2 = new TestBean3(300, "문자열2", new DataBean4(), new DataBean5());
		return t2;
	}

}
