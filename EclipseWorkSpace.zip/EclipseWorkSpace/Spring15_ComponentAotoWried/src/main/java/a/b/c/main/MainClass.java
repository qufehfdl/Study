package a.b.c.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;
import a.b.c.beans.TestBean3;
import a.b.c.config.BeanConfigClass;

public class MainClass {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(BeanConfigClass.class);

		// 자동주입이란? : bean객체가 만들어질때 기본적으로 가지고있어야할 값들을 자동으로 주입하는 개념

		// 세터와 게터를 이용한 자동주입

		TestBean1 t1 = ctx.getBean(TestBean1.class);

		// [1]타입을 이용한 자동 주입
		System.out.println("t1.data1 : " + t1.getData1());

		System.out.println("===================================================");

		// [2]이름을 이용한 자동 주입
		System.out.println("t1.data2 : " + t1.getData2());

		// [3]@Resource 을 이용한 이름을 가지고 주입
		System.out.println("t1.data3 : " + t1.getData3());

		// [2],[3] 은 가능은하지만 의미없음 이름을 사용해서 Bean을 사용할때는 @Bean을 쓰자

		System.out.println("===================================================");

		System.out.println("t1.data4 : " + t1.getData4());
		System.out.println("t1.data5 : " + t1.getData5());

		System.out.println("===================================================");

		// 생성자를 이용한 자동주입
		
		// 방법1
		TestBean2 t2 = ctx.getBean(TestBean2.class);
		System.out.println("t2.data1 : " + t2.getData1());
		System.out.println("t2.data2 : " + t2.getData2());
		System.out.println("t2.data3 : " + t2.getData3());
		System.out.println("t2.data4 : " + t2.getData4());

		// 방법2
		TestBean3 java1 = ctx.getBean("java1", TestBean3.class);
		System.out.println("java1 : " + java1.getData1());
		System.out.println("java1 : " + java1.getData2());
		System.out.println("java1 : " + java1.getData3());
		System.out.println("java1 : " + java1.getData4());

		ctx.close();
	}

}
