package a.b.c.advisor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.aop.aspectj.MethodInvocationProceedingJoinPoint;

public class AdvisorClass {
	// 메서드 호출 전
	public void beforeMethod() {
		System.out.println("beforeMethod 호출");
	}

	// 메서드 호출 후
	public void afterMethod() {
		System.out.println("afterMethod 호출");
	}

	// 위에 두개는 시점이 명확하지만 around는 명확하지 않음
	public Object aroundMethod(ProceedingJoinPoint pjp) throws Throwable {

		System.out.println("aroundMethod 호출1");

//		 원래의 메서드 호출 : 무조건 Object를 반환하기 때문에 형변환 필요
//						   그러니 Object로 받아주면 형변환 할 필요 없음	
		Object obj = pjp.proceed();

		System.out.println("aroundMethod 호출2");

		return obj;
	}
	
	// atterReturning : 아무 문제없이 잘 끝났을 경우 사용
	public void afterReturningMethod() {
		System.out.println("afterReturningMethod 호출");
	}
	
	// afterThrowing  : 에러가 났을 경우사용
	public void afterThrowingMethod(Throwable e1) {
		System.out.println("afterThrowingMethod 호출");
		System.out.println(e1);
		
	}
	
}
