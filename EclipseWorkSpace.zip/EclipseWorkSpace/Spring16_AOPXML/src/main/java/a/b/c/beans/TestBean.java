package a.b.c.beans;

public class TestBean {
	
	
	public int method1() {
		System.out.println("method1 호출");
		
		int a = 10/0; //에러나면 afterReturning 안됨
		
		return 100;
	}
}
