package a.b.c.beans;

public class TestBean1 {
	
	//관심사 등록o
	public void method1() {
		System.out.println("beans.TestBean1.method1() 관심사 등록 o");
	}
	//관심사 등록x
	public void method2() {
		System.out.println("beans.TestBean1.method2() 관심사 등록 x");
	}
	
	public void method1(int a1) {
		System.out.println("beans.TestBean1.method1(인트타입 1개)");
	}
	 
	public void method1(String a2) {
		System.out.println("beans.TestBean1.method1(문자열 타입 1개)");
	}
	
	public void method1(int a1 , int a2) {
		System.out.println("beans.TestBean1.method1(인트타입 2개)");
	}
	
	public void method1(int a1 , String a2) {
		System.out.println("beans.TestBean1.method1(인트타입 1개 스트링타입1개)");
	}
	
	//메서드 이름이 다르다면?
	public void method3() { 
		System.out.println("beans.TestBean1.method3() 메서드 이름이 다르다면?");
	}
	
	public int method4() {
		System.out.println("beans.TestBean1.method4() 리턴타입이 인트");
		return 3;
	}
}
