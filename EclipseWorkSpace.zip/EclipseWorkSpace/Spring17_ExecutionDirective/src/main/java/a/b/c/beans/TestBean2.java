package a.b.c.beans;

public class TestBean2 {
	
	public void method1() {
		System.out.println("beans.TestBean2.method1() 다른 클래스! ");
	}
	
}
