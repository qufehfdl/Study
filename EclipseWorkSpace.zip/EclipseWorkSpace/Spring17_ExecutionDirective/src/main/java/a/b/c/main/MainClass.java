package a.b.c.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.TestBean1;
import a.b.c.beans.TestBean2;

public class MainClass {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");

		TestBean1 xml1 = ctx.getBean("xml1", TestBean1.class);
		TestBean2 xml2 = ctx.getBean("xml2", TestBean2.class);
		a.b.c.beans2.TestBean1 xml3 = ctx.getBean("xml3", a.b.c.beans2.TestBean1.class);

		// 관심사 등록o
		xml1.method1();

		System.out.println("----------------------------------");

		// 관심사 등록x 위빙 안됨
		xml1.method2();

		System.out.println("----------------------------------");

		// 매개변수의 형태도 엄격하게 지킴
		xml1.method1(100);

		System.out.println("----------------------------------");

		xml1.method1("태화");

		System.out.println("----------------------------------");

		xml1.method1(3, 2);

		System.out.println("----------------------------------");

		xml1.method1(3, "태화~");

		System.out.println("----------------------------------");

		xml1.method3();

		// 다른 클래스
		System.out.println("----------------------------------");

		xml2.method1();

		// 다른 패키지
		System.out.println("----------------------------------");
    
		xml3.method1(); 
		
		// 리턴타입
		System.out.println("----------------------------------");
		    
		xml1.method4(); 

		ctx.close();
	}

}
