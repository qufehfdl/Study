package a.b.c.beans;

import org.springframework.stereotype.Component;


@Component 
public class TestBean1 {
	
	public void method1() {
		System.out.println("TestBean1의 method1 호출");
		
//		int a = 10/0; //예외 발생 코드
	}
}
