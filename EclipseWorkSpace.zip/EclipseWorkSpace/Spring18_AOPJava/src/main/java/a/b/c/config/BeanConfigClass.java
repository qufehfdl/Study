package a.b.c.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration //컨테이너로 쓰겠다
@ComponentScan(basePackages = {"a.b.c.beans" , "a.b.c.advisor"}) //객체를 만들겠다
@EnableAspectJAutoProxy //advisor 클래스에 설정되어있는 Annotation을 분석하여 AOP 세팅을 해랏
public class BeanConfigClass { 

}
