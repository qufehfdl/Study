package a.b.c.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import a.b.c.beans.JdbcBean;
//mapper 클래스 : 데이터를 가져올때 필요한것!
// select문으로 데이터를 가져올 때 어떤 컬럼의 값을 bean어디에 주입할 것인지 결정해줘야 하는데
// 이 역할을 하는 클래스를 Mapper 클래스 라고 부른다
//row가 매우 많다면 row하나의 정보를담을 bean객체를 여러가지 만들어서 list컬렉션등을 이용해 담았다면
//mapper 클래스를 이용해서 bean에 담는 과정만 만들어주면 됨 

@Component
public class MapperClass implements RowMapper<JdbcBean> {

	@Override
	public JdbcBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		JdbcBean bean = new JdbcBean();
		bean.setInt_data(rs.getInt("int_data"));
		bean.setStr_data(rs.getString("str_data"));
		return bean;
	}

}
