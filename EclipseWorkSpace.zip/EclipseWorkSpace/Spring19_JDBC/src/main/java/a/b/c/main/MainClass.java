package a.b.c.main;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.metadata.Db2CallMetaDataProvider;

import a.b.c.beans.JdbcBean;
import a.b.c.config.BeanConfigClass;
import a.b.c.db.jdbcDAO;

public class MainClass {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(BeanConfigClass.class);

		// dao를 가져온다
		jdbcDAO dao = ctx.getBean(jdbcDAO.class);
		
//		insert !!! -------------------------------------------------------------
		
//		//저장할 데이터를 담을 데이터를 만든다
//		JdbcBean bean1 = new JdbcBean();
//		bean1.setInt_data(1);
//		bean1.setStr_data("문자열1");
//		dao.insertData(bean1);
//
//		//저장할 데이터를 담을 데이터를 만든다
//		JdbcBean bean2 = new JdbcBean();
//		bean2.setInt_data(2);
//		bean2.setStr_data("문자열2");
//		dao.insertData(bean2);
//		
//		System.out.println("저장 완료");
		
//		update !!! -------------------------------------------------------------
		
//		JdbcBean bean4 = new JdbcBean();
//		bean4.setInt_data(1);
//		bean4.setStr_data("수정된 문자열");
//		dao.updateData(bean4);
		
//		select !!! -------------------------------------------------------------
		
		List<JdbcBean> list = dao.selectData();
		for (JdbcBean bean3 : list) {
			System.out.println("int data : "+ bean3.getInt_data());
			System.out.println("str data : "+ bean3.getStr_data());
			System.out.println("-------------------------------------------");
		}
		
//		delete !!! -------------------------------------------------------------
		
//		dao.deleteData(1);
		
		
		
		
		
		ctx.close();
	}

}
