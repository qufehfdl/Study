package a.b.c.beans;

public interface HelloWorld {
public void sayHello();
}
