package a.b.c.beans;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class JdbcBean {

	// SpringJDBC 프로젝트에서는 Mapper클래스가 어떤 컬럼의 값을 어디Bean에 집어넣겟다를 설정해 줬다면
	// 이번 프로젝트는 반드시 컬럼의 이름과 변수의 이름이 동일해야함!

	private int int_data;
	private String str_data;

	public int getInt_data() {
		return int_data;
	}

	public void setInt_data(int int_data) {
		this.int_data = int_data;
	}

	public String getStr_data() {
		return str_data;
	}

	public void setStr_data(String str_data) {
		this.str_data = str_data;
	}

}
