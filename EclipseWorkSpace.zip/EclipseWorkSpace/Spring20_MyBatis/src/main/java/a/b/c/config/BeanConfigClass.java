package a.b.c.config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import a.b.c.mapper.MapperInterface;

@Configuration
@ComponentScan(basePackages = "a.b.c.beans")
public class BeanConfigClass {

	@Bean
	public BasicDataSource source() {
		BasicDataSource source = new BasicDataSource();
		source.setDriverClassName("oracle.jdbc.OracleDriver");
		source.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		source.setUsername("system");
		source.setPassword("1042");
		return source;
	}

//	------------------------------- mybatis 세팅-----------------------------------------------

	// JDBC할 때는 JDBCTemplate 클래스를 사용했다면 mybatis는 JDBCSession을 사용
	// 실제로 작업을 할 때는 JDBCSession을 사용하지 않고 Mapper로 작업함

	// SqlSessionFactory : jdbc를 처리하는 객체
	@Bean
	public SqlSessionFactory factory(BasicDataSource source) throws Exception {
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();

		// dataSource세팅(접속정보)
		factoryBean.setDataSource(source);
		SqlSessionFactory factory = factoryBean.getObject();
		return factory;

	}

	// Mapper를 세팅 : Mapper가 실제로 쿼리문 처리를 다 함
	@Bean
	public MapperFactoryBean<MapperInterface> testMapper(SqlSessionFactory factory) throws Exception {
		MapperFactoryBean<MapperInterface> factoryBean = new MapperFactoryBean<>(MapperInterface.class);

		factoryBean.setSqlSessionFactory(factory);

		return factoryBean;
	}

//	------------------------------- mybatis 세팅 끝-----------------------------------------------

}
