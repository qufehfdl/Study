package a.b.c.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import a.b.c.beans.JdbcBean;

public interface MapperInterface {

	@Results({
			// int_data컬럼의 값은 지정된 bean의 int_data에다가 넣겠다
			// str_data컬럼의 값은 지정된 bean의 str_data에다가 넣겠다
			@Result(column = "int_data", property = "int_data"), @Result(column = "str_data", property = "str_data") })

//쿼리문 작성
	// 쿼리문을 실행할 메서드를 추상메서드로 정의

	@Select("select int_data,str_data from taehwa.jdbc_table")
	List<JdbcBean> selectData();

	
	@Insert("insert into taehwa.jdbc_table(int_data,str_data) values(#{int_data},#{str_data})")
	void insert_data(JdbcBean bean); // bean이 가지고잇는 값을 ${}에 바인딩

	
	@Update("update taehwa.jdbc_table set str_data = #{str_data} where int_data=#{int_data}")
	void update_data(JdbcBean bean);// bean이 가지고잇는 값을 ${}에 바인딩
	
	
	//만약 쿼리문에 바인딩할 값이 객체가아니라 단지 값 1개라면 아무거나 써줘도 됨
	@Delete("delete from taehwa.jdbc_table where int_data=#{아무거나}")
	void delete_data(int int_data);

}
