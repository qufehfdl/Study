package a.b.c.beans;

public class TestBean {

}
