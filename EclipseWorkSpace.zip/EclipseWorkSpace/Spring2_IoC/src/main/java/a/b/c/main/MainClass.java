package a.b.c.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import a.b.c.beans.TestBean;

public class MainClass {

	public static void main(String[] args) {

//		test1();
		test2();
	}

	// ApplicationContext - 패키지 내부
	public static void test1() {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");

		TestBean t1 = ctx.getBean("t1", TestBean.class);
		System.out.println(t1);

		ctx.close();
	}

	// ApplicationContext - 패키지 외부
	public static void test2() {
		FileSystemXmlApplicationContext ctx = new FileSystemXmlApplicationContext("beans.xml");

		TestBean t2 = ctx.getBean("t2", TestBean.class);
		System.out.println(t2);

		ctx.close();
	}
}
