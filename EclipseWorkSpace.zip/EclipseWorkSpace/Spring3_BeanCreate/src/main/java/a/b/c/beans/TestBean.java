package a.b.c.beans;

public class TestBean {

	public TestBean() {
		System.out.println("TestBean의 생성자");
	}
}
