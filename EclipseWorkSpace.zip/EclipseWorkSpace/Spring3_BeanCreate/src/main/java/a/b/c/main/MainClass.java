package a.b.c.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.TestBean;

public class MainClass {

	public static void main(String[] args) {
		//생성하는 순간 IoC컨테이너에 객체가 등록되어 콘솔에 TestBean()생성자가 호출된다
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");
		
		
		// id가 test1인 bean 객체의 주소값을 받아온다
		TestBean t1 = ctx.getBean("test1", TestBean.class);
		System.out.println(t1);

		// id가 test1인 bean 객체의 주소값을 또!! 받아온다
		// 생성자는 한번만 호출 , 계속 같은 객체의 주소값을 반환
		TestBean t2 = ctx.getBean("test1", TestBean.class);
		System.out.println(t2);

		// id가 test2인 bean 객체의 주소값을 받아온다
		// lazy-init="true"이기 때문에 최초의 getBean메서드를 호출해야 객체가 생성된다
		// 생성된 객체는 singleton 이기때문에 동일한 id값으로 getBean()시 객체가 또 생성되지 않고 주소값만 반환
		TestBean t3 = ctx.getBean("test2", TestBean.class);
		System.out.println(t3);
		TestBean t4 = ctx.getBean("test2", TestBean.class);
		System.out.println(t4);
		
		// id가 test3인 bean 객체의 주소값을 받아온다
		// scope="prototype" = getBean()호출 때 마다 새로운 객체가 생성
		TestBean t5 = ctx.getBean("test3", TestBean.class);
		System.out.println(t5);
		
		TestBean t6 = ctx.getBean("test3", TestBean.class);
		System.out.println(t6);
		
		// IoC컨테이너 종료 : 객체도 소멸!
		ctx.close();
	}

}
