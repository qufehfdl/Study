package a.b.c.processor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class TestBeanPostProcessor implements BeanPostProcessor {

	// init메서드 호출 전
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("bofore");
		// Object bean : 빈객체의 주소값이 들어옴
		// String beanName : 빈객체의 id값이 들어옴
		// bean마다 따로따로 작업하고싶다면 String beanName에 id속성이 들어오므로
		switch (beanName) {
		case "t1":
			System.out.println("id가 t1인 bean객체 생성");
			break;
		case "t2":
			System.out.println("id가 t2인 bean객체 생성");
			break;

		default:
			break;
		}
		return bean;
	}

	// init메서드 호출 후
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("after");
		return bean;
	}
}
