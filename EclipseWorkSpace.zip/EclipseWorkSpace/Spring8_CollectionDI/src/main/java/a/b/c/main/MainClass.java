package a.b.c.main;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;


import org.springframework.context.support.ClassPathXmlApplicationContext;

import a.b.c.beans.DataBean;
import a.b.c.beans.TestBean;

public class MainClass {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("a/b/c/config/beans.xml");

		TestBean t1 = ctx.getBean("t1" , TestBean.class);
		
		//리스트!
		List<String> list1 = t1.getList1();
		for (String string : list1) {
			System.out.println(string);
		}
		
		List<Integer> list2 = t1.getList2();
		for (int i : list2) {
			System.out.println(i);
		}
		
		List<DataBean> list3 = t1.getList3();
		for (DataBean dataBean : list3) {
			System.out.println(dataBean); 
		}
		
		System.out.println("=================================================");
		//set!
		Set<String> set1 = t1.getSet1();
		Set<Integer> set2 = t1.getSet2();
		Set<DataBean> set3 = t1.getSet3();
		
		for (String str : set1) {
			System.out.println(str);
		}
		for (Integer in : set2) {
			System.out.println(in);
		}
		for (DataBean d : set3) {
			System.out.println(d);
		}

		System.out.println("=================================================");
		//맵!
		Map<String, Object> map1 = t1.getMap1();
		
		String a1 = (String) map1.get("a1");
		int a2 = (Integer) map1.get("a2");
		DataBean a3 = (DataBean) map1.get("a3");
		DataBean a4 = (DataBean) map1.get("a4");
		List<String> a5 = (List<String>) map1.get("a5");
		
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		System.out.println(a4);
		System.out.println(a5);
		
		System.out.println("=================================================");
		
		//프로퍼티!
			//무조건 문자열로만 출력
		Properties prop1 = t1.getProp1();
		
		String p1 = prop1.getProperty("p1");
		String p2 = prop1.getProperty("p2");
		String p3 = prop1.getProperty("p3");
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		
		
		
		
		ctx.close();
	}

}
