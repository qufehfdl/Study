package a.b.c.config;
 
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.DispatcherServlet;

public class SpringConfigClass implements WebApplicationInitializer {

//	웹 어플리케이션 실행 시 WebApplicationInitializer를 구현한 클래스가 존재한다면
//	그 클래스의 onStartup()메서드를 자동으로 호출해 준다
//	즉 web.xml파일을 로딩하는것 대신에 이 메서드를 호출하는 것
//	그러므로 web.xml 내용을 자바코드로 구현 하면 됨
	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {

// --------------------------------------------------------------------------------------------------
		// SpringMVC 프로젝트 설정을 위해 작성하는 클래스의 객체를 생성
		AnnotationConfigWebApplicationContext ServletAppContext = new AnnotationConfigWebApplicationContext();
		ServletAppContext.register(ServletAppContext.class);

		// 요청 발생 시 요청을 처리하는 서블릿을 DispatcherServlet으로 설정한다
		DispatcherServlet dispatcherServlet = new DispatcherServlet(ServletAppContext);
		ServletRegistration.Dynamic servlet = servletContext.addServlet("dispatcher", dispatcherServlet);

		// 부가 설정
		servlet.setLoadOnStartup(1); // 가장먼저 로딩
		servlet.addMapping("/"); // 모든 요청에 대해서 이 서블릿이 가장먼저 받아들이겠다

		// 아래와 같다

//		현재 웹 어플리케이션에서 받아들이는 모든 요청에 대해 appServlet이라는 이름으로 정의되어 있는 서블릿을 사용하겠다
//		<servlet-mapping>
//			<servlet-name>appServlet</servlet-name>
//			<url-pattern>/</url-pattern>
//		</servlet-mapping>

//		요청 정보를 분석해서 컨트롤러를 선택하는 서블릿을 지정
//		<servlet>
//			<servlet-name>appServlet</servlet-name>
//			Spring MVC에서 제공하고 있는 기본 서블릿을 지정
//			<servlet-class>org.springframework.web.servlet.DispatcherServlet
//			</servlet-class>
//			Spring MVC 설정을 위한 xml파일을 지정
//			<init-param>
//				<param-name>contextConfigLocation</param-name>
//				<param-value>/WEB-INF/config/servlet-context.xml</param-value>
//			</init-param>
//			<load-on-startup>1</load-on-startup>
//		</servlet>

// --------------------------------------------------------------------------------------------------

// 		Bean을 정의할 클래스를 지정

		AnnotationConfigWebApplicationContext rootAppContext = new AnnotationConfigWebApplicationContext();
		rootAppContext.register(RootAppContext.class);

		// 아래와 같다

//		Bean을 정의할 xml파일을 지정
//		<context-param>
//			<param-name>contextConfigLocation</param-name>
//			<param-value>/WEB-INF/config/root-context.xml</param-value>
//		</context-param>

// --------------------------------------------------------------------------------------------------		

// 		리스너 설정

		ContextLoaderListener listener = new ContextLoaderListener(rootAppContext);
		servletContext.addListener(listener);

		// 아래와 같다

//		리스너 설정
//		<listener>
//			<listener-class>org.springframework.web.context.ContextLoaderListener
//			</listener-class>
//		</listener>

// --------------------------------------------------------------------------------------------------				

//		파라미터 인코딩 필터 설정
		
		FilterRegistration.Dynamic filter = servletContext.addFilter("encodingFilter", CharacterEncodingFilter.class);
		filter.setInitParameter("encoding", "UTF-8");
		filter.addMappingForServletNames(null, false, "dispatcher");

		// 아래와 같다

//		파라미터 인코딩 필터 설정
//		<filter>
//			<filter-name>encodingFilter</filter-name>
//			<filter-class>org.springframework.web.filter.CharacterEncodingFilter
//			</filter-class>
//			<init-param>
//				<param-name>encoding</param-name>
//				<param-value>UTF-8</param-value>
//			</init-param>
//		</filter>
//		<filter-mapping>
//			<filter-name>encodingFilter</filter-name>
//			<url-pattern>/*</url-pattern>
//		</filter-mapping>

	}
}
