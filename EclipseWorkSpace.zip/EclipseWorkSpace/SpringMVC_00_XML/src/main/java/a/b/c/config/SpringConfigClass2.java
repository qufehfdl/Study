package a.b.c.config;

import javax.servlet.Filter;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.beans.propertyeditors.ClassArrayEditor;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import oracle.net.aso.e;

//			SpringConfigClass 와 비교해 보자!!

//			SpringConfigClass 는 WebApplicationInitializer를 구현했다
//			직접 작성한 것이기 때문에 자율도,확장성이 높은 반면 코드가 복잡하다
//			AbstractAnnotationConfigDispatcherServletInitializer를 상속받으면 자율도와 확장성이 떨어지지만
//			쉽게 만들 수 있다

public class SpringConfigClass2 extends AbstractAnnotationConfigDispatcherServletInitializer {

//------------------------------------------------------------------------------------------------	
	
//				DispatcherServlet에 맵핑할 요청 주소를 세팅

//	servlet.addMapping("/");  와 같다
	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}
	
//------------------------------------------------------------------------------------------------

//				SpringMVC 프로젝트 설정을 위한 클래스를 지정

//	SpringMVC 프로젝트 설정을 위해 작성하는 클래스의 객체를 생성
//	AnnotationConfigWebApplicationContext ServletAppContext = new AnnotationConfigWebApplicationContext();
//	ServletAppContext.register(ServletAppContext.class); 와 같다
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] { ServletAppContext.class };
	}

//------------------------------------------------------------------------------------------------
	
//				Bean을 정의할 클래스를 지정

//	AnnotationConfigWebApplicationContext rootAppContext = new AnnotationConfigWebApplicationContext();
//	rootAppContext.register(RootAppContext.class);		와 같다

	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] { RootAppContext.class };
	}

//------------------------------------------------------------------------------------------------	
	
//				파라미터 인코딩 필터 설정

//	FilterRegistration.Dynamic filter = servletContext.addFilter("encodingFilter", CharacterEncodingFilter.class);
//	filter.setInitParameter("encoding", "UTF-8");
//	filter.addMappingForServletNames(null, false, "dispatcher"); 와 같다

	@Override
	protected Filter[] getServletFilters() {
		CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter();
		encodingFilter.setEncoding("UTF-8");
		return new Filter[] { encodingFilter };
	}
}
