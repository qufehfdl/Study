package a.b.c.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Sub1Controller {

	@RequestMapping(value = "/sub1/test3" , method = RequestMethod.GET)
	public String test3() {
		return "sub1/test3";
	}
	
// 		프로토콜		도메인		       context path        요청주소
//		http:  //localhost:8090 / SpringMVC_01_URLMapping / sub1 / test3
	
	
	@RequestMapping(value = "/sub1/test4" , method = RequestMethod.GET)
	public String test4() {
		return "sub1/test4";
	}
	
//		프로토콜		도메인		       context path        요청주소
//	http:  //localhost:8090 / SpringMVC_01_URLMapping / sub1 / test4	
}
