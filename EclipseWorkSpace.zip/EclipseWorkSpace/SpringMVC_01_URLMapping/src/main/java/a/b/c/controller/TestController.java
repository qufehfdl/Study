package a.b.c.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class TestController {

// ---------------------------- SpringMVC에서의 주소 ----------------------------
	
	@RequestMapping(value = "test1" , method = RequestMethod.GET)
	public String test1() {    //메서드 이름은 자유롭게 해줘도 됨!
		return "test1";
	}
// 프로토콜		도메인		       context path        요청주소
//	http:  //localhost:8090 / SpringMVC_01_URLMapping / test1
	
	
	@RequestMapping(value = "test2" , method = RequestMethod.GET)
	public String test2() {    
		return "test2";
	}
// 프로토콜		도메인		       context path        요청주소
//	http:  //localhost:8090 / SpringMVC_01_URLMapping / test2
	
}
