package a.b.c.config;

import javax.servlet.Filter;
import javax.servlet.FilterRegistration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.beans.propertyeditors.ClassArrayEditor;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

// SpringConfigClass 는 WebApplicationInitializer를 구현했기 때문에
//직접 작성 하였기 때문에 자율도나 확장성이 높은 반면 코드가 복잡하다

//SpringConfigClass2 는 AbstractAnnotationConfigDispatcherServletInitializer를 상속받아
//작성하는데 자율도나 확장성이 없지만 쉽게 만들 수 있다

public class SpringConfigClass2 extends AbstractAnnotationConfigDispatcherServletInitializer {

// ----------------------------------------------------------------------------------------------------
	
					// DispatcherServlet에 맵핑할 요청 주소를 세팅
	
	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}
	

//	servlet.addMapping("/"); 와 같음

// ----------------------------------------------------------------------------------------------------
	
					// SpringMVC 프로젝트 설정을 위한 클래스를 지정
	
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] { ServletAppContext.class };
	}
	
	
//	AnnotationConfigWebApplicationContext ServletAppContext = new AnnotationConfigWebApplicationContext();
//	ServletAppContext.register(ServletAppContext.class); 와 같음
	
	

// ----------------------------------------------------------------------------------------------------

					// Bean을 정의할 클래스를 지정
	
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] { RootAppContext.class };
	}
	
	
//	AnnotationConfigWebApplicationContext rootAppContext = new AnnotationConfigWebApplicationContext();
//	rootAppContext.register(RootAppContext.class);		와 같음
	
// ----------------------------------------------------------------------------------------------------

					// 파라미터 인코딩 필터 설정
	
	@Override
	protected Filter[] getServletFilters() {
		CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter();
		encodingFilter.setEncoding("UTF-8");
		return new Filter[] { encodingFilter };
	}
	
	
//	FilterRegistration.Dynamic filter = servletContext.addFilter("encodingFilter", CharacterEncodingFilter.class);
//	filter.setInitParameter("encoding", "UTF-8");
//	filter.addMappingForServletNames(null, false, "dispatcher"); 와 같음

}
