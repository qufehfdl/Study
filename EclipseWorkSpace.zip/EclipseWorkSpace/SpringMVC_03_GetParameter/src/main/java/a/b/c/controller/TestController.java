package a.b.c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;

@Controller
public class TestController {

//	----------------- 파라미터 추출하기 : Servlet/JSP 방식 -----------------

	@GetMapping("/test1") // 브라우저가 요청하는 요청 정보가 담겨져있는 request객체를 주입 받을 수 있다
	public String test1(HttpServletRequest request) {
		String data1 = request.getParameter("data1"); // 파라미터 데이터는 무조건 문자열로 추출됨!
		String data2 = request.getParameter("data2");

		String data3[] = request.getParameterValues("data3");

		System.out.println("data1 : " + data1);
		System.out.println("data2 : " + data2);

		for (String string : data3) {
			System.out.println("data3 : " + string);
		}
		return "result";
	}

	@PostMapping("/test2")
	public String test2(HttpServletRequest request) {
		String data1 = request.getParameter("data1");
		String data2 = request.getParameter("data2");

		String data3[] = request.getParameterValues("data3");

		System.out.println("data1 : " + data1);
		System.out.println("data2 : " + data2);

		// 체크박스에 아무것도 체크하지 않으면 null 값이 전송 이때 null로 반복문을 돌리기 때문에 에러가남
		if (data3 != null) {
			for (String string : data3) {
				System.out.println("data3 : " + string);
			}
		}
		return "result";
	}

	// Post방식도 같으므로 post는 타이핑 x
	@GetMapping("/test3")
	public String test3(WebRequest request) {

		String data1 = request.getParameter("data1");
		String data2 = request.getParameter("data2");

		String data3[] = request.getParameterValues("data3");

		System.out.println("data1 : " + data1);
		System.out.println("data2 : " + data2);

		for (String string : data3) {
			System.out.println("data3 : " + string);
		}
		return "result";
	}

//	----------------- 파라미터 추출하기 : SpringMVC 방식 -----------------

//		◆ @PathVariable 사용하기
	
//		중괄호가 있다면 각 자리에 해당하는 [문자열] 값을 해당 변수의 이름으로 자동 주입 
//		정수값으로 받고 싶다면 int로 바꿔주면 된다

//		중괄호가 없다면 파라미터를 추출하는게 아닌
//		요청주소가 /test4/data1/data2/data3 인 경우에 이 메서드가 호출하는게 되게 된다 

//		request.getParameter로 직접 추출하게 되면 무조건 문자열로 추출되기에
//		SpirngMVC에서는 파라미터로 넘어오는 값을 메서드의 매개변수로 직접 주입받아 사용하는 경우가 많음
	
		@GetMapping("/test4/{data1}/{data2}/{data3}")
		public String test4(@PathVariable int data1,
						    @PathVariable int data2,
						    @PathVariable int data3) {
			
			System.out.println("data1 : " + data1);
			System.out.println("data2 : " + data2);
			System.out.println("data3 : " + data3);
			
			int add = data1 + data2 + data3;
			System.out.println(add);
			return "result";
		}
		
		
//		◆ @RequestParam 사용하기
		
		@GetMapping("/test5")
		public String test5(@RequestParam int data1, 
							@RequestParam int data2,
							@RequestParam int data3[] ) {
			
			System.out.println("data1 : " + data1);
			System.out.println("data2 : " + data2);
			
			for (int i : data3) {
				System.out.println("data3 : " + i);
			} 
			return "result";
		}
		
//		◆ @RequestParam(value="~")  :  파라미터의 이름과 변수의 이름이 다를 경우 파라미터 이름을 지정한다
		
		@GetMapping("/test6")			//data1 이름으로 넘어오는 데이터는 value1에 담겠습니다!! 라는 뜻
		public String test6(@RequestParam(value = "data1") int value1, 
							@RequestParam(value = "data2") int value2, 
							@RequestParam(value = "data3") int value3[] ) {
			
			System.out.println("data1 : " + value1);
			System.out.println("data2 : " + value2);
			
			for (int i : value3) {
				System.out.println("data3 : " + i);
			} 
			return "result";
		}
		
//		◆ @RequestParam(required="~")  :  false를 설정하면 지정된 이름의 파라미터가 없을 경우 null이 주입!
		
		@GetMapping("/test7")			
		public String test7(@RequestParam int data1, 
							@RequestParam(required = false) String data2,
//									data2라는값이 넘어오면 세팅을 하고 넘어오지 않았으면 null값으로 처리하겠다						
							@RequestParam(defaultValue = "0") int data3 ) {
//									data3이라는 값이 넘어오지 않는다면 기본값을 설정할 수 있다
			System.out.println("data1 : " + data1);
			System.out.println("data2 : " + data2);
			System.out.println("data3 : " + data3);
			return "result"; 
		}
}
