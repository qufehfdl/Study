package a.b.c.controller;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import a.b.c.beans.DataBean;
import a.b.c.beans.DataBean2;

@Controller
public class TestController {

	// 파라미터로 들어오는 데이터가 숫자로 들어오더라 하더라도 자동으로 형변환되지 않기때문에 무조건 String으로 받아준다
	// 정수값으로 받기 위해서는 직접 변환 해주어야 함

	@GetMapping("/test1")
	public String test1(@RequestParam Map<String, String> map, @RequestParam List<String> data4) {
		String data1 = map.get("data1");
		String data2 = map.get("data2");
		String data3 = map.get("data3");

		System.out.println("data1 : " + data1);
		System.out.println("data2 : " + data2);
		System.out.println("data3 : " + data3);

		for (String string : data4) {
			System.out.println("data4 : " + string);
		}
		return "result";
	}
	
	// @ModelAttribute 를 이용해서 객체로 파라미터 추출하기
	
	@GetMapping("/test2")							//@ModelAttribute 는 생략가능
	public String test2(@ModelAttribute DataBean bean1 ,  DataBean2 bean2) {

		System.out.println("bean1.data1 : " + bean1.getData1());
		System.out.println("bean1.data2 : " + bean1.getData2());

		for (int num1 : bean1.getData3()) {
			System.out.println("bean1.data3 : " + num1);
		}
		
		System.out.println("---------------------------------");
		
		System.out.println("bean2.data1 : " + bean2.getData1());
		System.out.println("bean2.data2 : " + bean2.getData2());
		
		return "result";
	}

}
