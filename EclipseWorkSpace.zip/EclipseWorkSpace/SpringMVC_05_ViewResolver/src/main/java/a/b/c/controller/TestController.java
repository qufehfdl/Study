package a.b.c.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {
//	SpringMVC에는 ModelAndView라는 클래스가 존재한다
//    				- MVC패턴에서  Model : 데이터를 관리
//                  				 View  : 눈에보이는 화면을 관리 
	
	
	//파라미터에서 넘어온값을 ${param.~}을 사용해서 이용
	@GetMapping("test1")
	public String test1() {
		return "test1";
	}
	
	// HttpServletRequest 객체를 주입받아서 이용
	// request객체에 담긴 데이터들은 모두 ModelAndView에 담기고 ModelAndView가 ViewResolver로 전달 됨
	@GetMapping("test2")
	public String test2(HttpServletRequest request) {
		request.setAttribute("data1", 100);
		request.setAttribute("data2", 200);
		return "test2";
	}
	
	//model에 담는것은 모두 request에 담겨서 ViewResolver로 넘어감
	//request객체에 담는것 보다 다양한 기능이 있음
	@GetMapping("test3")
	public String test3(Model model) {
		
		model.addAttribute("data1", 400);
		model.addAttribute("data2", 500);
		
		return "test3";
	}
	
	@GetMapping("test4")
	public ModelAndView test4(ModelAndView mv) {
		mv.addObject("data1", 1000);
		mv.addObject("data2", 2000);
		
		mv.setViewName("test4");
		return mv;
	}
	
	
}
