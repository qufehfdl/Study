package a.b.c.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import a.b.c.beans.UserDataBean;

@Controller
public class TestController {
	
	//커스텀태그 사용 x
	//@모델어트리뷰트는 생략!
	@GetMapping("test1")
	public String test1(UserDataBean bean) {
		
		bean.setUser_name("홍태화");
		bean.setUser_id("asdf");
		bean.setUser_pw("1234");
		bean.setUser_postcode("5678");
		bean.setUser_address1("주소1");
		bean.setUser_address2("주소2");
		
		return "test1";
	}
	
	//커스텀태그 사용 o
	//@모델어트리뷰트는 생략!
	@GetMapping("test2")
	public String test2(UserDataBean bean) {
		 
		bean.setUser_name("홍태화");
		bean.setUser_id("asdf");
		bean.setUser_pw("1234");
		bean.setUser_postcode("5678");
		bean.setUser_address1("주소1");
		bean.setUser_address2("주소2");
		
		return "test2";
	}
	
	//커스텀태그 사용 o
	//@모델어트리뷰트 이름 사용
	@GetMapping("test3")
	public String test3(@ModelAttribute(name = "taehwa") UserDataBean bean) {
		 
		bean.setUser_name("홍태화");
		bean.setUser_id("asdf");
		bean.setUser_pw("1234");
		bean.setUser_postcode("5678");
		bean.setUser_address1("주소1");
		bean.setUser_address2("주소2");
		
		return "test3";
	}
	
	//커스텀태그 사용 o
	//@모델어트리뷰트 사용 x
	//Model객체 사용    :  자동으로 request 객체에 주입되지 않음
	@GetMapping("test4")
	public String test4(Model model) {
		UserDataBean bean = new UserDataBean();
		bean.setUser_name("홍태화");
		bean.setUser_id("asdf");
		bean.setUser_pw("1234");
		bean.setUser_postcode("5678");
		bean.setUser_address1("주소1");
		bean.setUser_address2("주소2");
		
		model.addAttribute("taehwaModel", bean);
		
		return "test4";
	}
	
	
	
	
	
}
