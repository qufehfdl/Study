package a.b.c.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import a.b.c.beans.DataBean;

@Controller
public class TestController {

	@GetMapping("/test1")
	public String taehwa1(DataBean bean) {
		
		bean.setA1("data1");
		bean.setA2("data2");
		bean.setA3("data3");
		bean.setA4("data4");
		return "test1";
	}
	
}
