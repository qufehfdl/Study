package a.b.c.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;

import a.b.c.beans.DataBean1;
import a.b.c.beans.DataBean2;

//프로젝트 작업시 사용할 Bean을 정의하는 클래스
@Configuration
public class RootAppContext {
	
	
//  byType 	
//	XML방식 : <bean class="a.b.c.beans.DataBean1" scope="request"></bean> 와 같다
	@Bean
	@RequestScope
	public DataBean1 dataBean1() {
		return new DataBean1();
	}
	
//	byName	
	@Bean("requestBean2")
	@RequestScope
	public DataBean2 dataBean2() {
		return new DataBean2();
	}
	
}
