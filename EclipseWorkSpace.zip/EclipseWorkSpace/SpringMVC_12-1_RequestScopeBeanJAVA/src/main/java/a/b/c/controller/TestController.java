package a.b.c.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import a.b.c.beans.DataBean1;
import a.b.c.beans.DataBean2;
import a.b.c.beans.DataBean3;
import a.b.c.beans.DataBean4;

@Controller
public class TestController {

// @RequestScope : Bean이 주입되는 시기가 새로운 요청이 발생될 때 객체를 만들어서 주입하겠다는 의미이지
//				   request영역에 저장하겠다는 의미가 아님
//				   JSP까지 넘기고 싶으면 Model이나 여러방법으로 request 영역에 넣은 후 넘겨야 함

//	@RequestScope으로 되어있기 때문에 여기 주입되는 시점이 새로운 요청이 발생했을 때 Bean에 주입됨
//  test1으로 요청이오면 여기에 바로 주입이 되고 포워딩 함     ※포워딩은 새로운 요청이아님! 리다이렉트가 새로운 요청
//	포워딩은 새로운 요청이 아니기에 문자열1,문자열2 가 셋팅된 객체가 result메서드로 그대로 넘어감

	
	
	@Autowired // byType
	DataBean1 requestBean1;

	@Resource(name = "requestBean2") // byName
	DataBean2 requestBean2;
	
	@Autowired
	DataBean3 requestBean3;
	
	@Resource(name = "requestBean4")
	DataBean4 requestBean4;
	

	@GetMapping("/test1")
	public String test1() {
		requestBean1.setData1("문자열1");
		requestBean1.setData2("문자열2");

		requestBean2.setData3("문자열3");
		requestBean2.setData4("문자열4");
		
		requestBean3.setData5("문자열5");
		requestBean3.setData6("문자열6");
		
		requestBean4.setData7("문자열7");
		requestBean4.setData8("문자열8");

		return "forward:/result1";
	}

	@GetMapping("/result1")
	public String result1(Model model) {
		System.out.println("requestBean1.getData1() : " + requestBean1.getData1());
		System.out.println("requestBean1.getData2() : " + requestBean1.getData2());

		System.out.println("requestBean2.getData3() : " + requestBean2.getData3());
		System.out.println("requestBean2.getData4() : " + requestBean2.getData4());
		
		System.out.println("requestBean3.getData5() : " + requestBean3.getData5());
		System.out.println("requestBean3.getData6() : " + requestBean3.getData6());
		
		System.out.println("requestBean3.getData7() : " + requestBean4.getData7());
		System.out.println("requestBean3.getData8() : " + requestBean4.getData8());

		model.addAttribute("requestBean1", requestBean1);
		model.addAttribute("requestBean2", requestBean2);
		model.addAttribute("requestBean3", requestBean3);
		model.addAttribute("requestBean4", requestBean4);
		return "result1";
	}

}
