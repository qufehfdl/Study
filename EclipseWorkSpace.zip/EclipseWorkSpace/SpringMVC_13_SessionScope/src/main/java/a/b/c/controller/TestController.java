package a.b.c.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import a.b.c.beans.DataBean1;

@Controller
//이 컨트롤러에서 sessionBean1이라는 이름으로 @ModelAttribute를 통해 주입받는 객체는
//request영역이 아니라 session영역에 저장되는 객체입니다 라고 명시!!!  배열을 통해 복수도 가능
@SessionAttributes({ "sessionBean1", "sessionBean2" })
public class TestController {

	// 일단 세션객체에 저장이 되어있어야지만 주입이 가능하기 때문에
	// 객체를 받아서 반환하는 메서드를 만들어 줘야함 ※생략되면 오류
	@ModelAttribute("sessionBean1")
	public DataBean1 sessionBean1() {
		return new DataBean1();
	}

	@ModelAttribute("sessionBean2")
	public DataBean1 sessionBean2() {
		return new DataBean1();
	}

//	[JSP 방법 : 리퀘스트를 주입받아 세션객체를 만듬]
//	@GetMapping("/test1")
//	public String test1(HttpServletRequest request) {
//		
//		HttpSession session = request.getSession();
//		session.setAttribute("data1", "문자열");
//		return "test1";
//	}
//	
//	@GetMapping("/result1")
//	public String result1(HttpServletRequest request) {
//		HttpSession session = request.getSession();
//		String data1 = (String) session.getAttribute("data1");
//		System.err.println("data1 : " + data1);
//		return "result1";
//	}

//	[Spring 방법 : 바로 세션객체 주입] -----------------------------------------------------------------

// 데이터를 추출--------------------
	@GetMapping("/test1")
	public String test1(HttpSession session) {
		session.setAttribute("data1", "문자열");
		return "test1";
	}

	@GetMapping("/result1")
	public String result1(HttpSession session) {
		String data1 = (String) session.getAttribute("data1");
		System.out.println("data1 : " + data1);
		return "result1";
	}

// 객체를 추출--------------------
	@GetMapping("/test4")
	public String test4(HttpSession session) {
//	public String result(@SessionAttribute("bean1") DataBean1 bean1) {
		// 이건 세션 영역에 이미 bean1이름으로 저장되어있는 객체를 주입받는 것이지
		// 새로운 세션객체를 만들어서 bean1에다 주입하라는게 아님 [ @ModelAttribute랑은 다름 ]

		DataBean1 bean1 = new DataBean1();
		bean1.setData1("문자열2");
		bean1.setData2("문자열3");
		session.setAttribute("bean1", bean1);
		return "test4";
	}

	@GetMapping("/result4")
//	public String result4(HttpSession session) {
	// 이건 세션 영역으로부터 직접 추출해낸 방법
//		DataBean1 bean1 = (DataBean1) session.getAttribute("bean1");

	public String result(@SessionAttribute("bean1") DataBean1 bean1) {
//	@SessionAttribute("~")를 사용하여 메서드 매개변수로 session영역에 저장되어 있는 bean을 바로 주입받을 수 있다
		System.out.println("bean1.data1 : " + bean1.getData1());
		System.out.println("bean1.data2 : " + bean1.getData2());
		return "result4";
	}

// @ModelAttribute를 세션영역으로 변환--------------------

	@GetMapping("/test5")
	public String test5(@ModelAttribute("sessionBean1") DataBean1 sessionBean1,
						@ModelAttribute("sessionBean2") DataBean1 sessionBean2) {
		sessionBean1.setData1("문자열10");
		sessionBean1.setData2("문자열11");

		sessionBean2.setData1("문자열12");
		sessionBean2.setData2("문자열13");
		return "test5";
	}

	@GetMapping("/result5")
	public String result5(@ModelAttribute("sessionBean1") DataBean1 sessionBean1,
						  @ModelAttribute("sessionBean2") DataBean1 sessionBean2) {
		System.out.println("sessionBean1.data1 : " + sessionBean1.getData1());
		System.out.println("sessionBean1.data2 : " + sessionBean1.getData2());

		System.out.println("sessionBean2.data1 : " + sessionBean2.getData1());
		System.out.println("sessionBean2.data2 : " + sessionBean2.getData2());
		return "result5";
	}

}
