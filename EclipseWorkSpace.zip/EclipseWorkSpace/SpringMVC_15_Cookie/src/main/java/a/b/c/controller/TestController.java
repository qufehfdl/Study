package a.b.c.controller;

import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TestController {

	@GetMapping("/save_cookie")//응답결과에 쿠키 저장정보를 담아 보내는것이기 때문에 response객체를 주입받아야 함
	public String save_cookie(HttpServletResponse response) {
		try {
			//데이터 준비
			//브라우저에 따라 한글데이터가 깨질수 있기때문에 한글데이터를 보내고 받을때는 인코딩 디코딩 해주기
			String data1 = URLEncoder.encode("문자열1","UTF-8");
			String data2 = URLEncoder.encode("문자열2","UTF-8");
			
			//쿠키객체 만듬
			Cookie cookie1 = new Cookie("cookie1", data1);
			Cookie cookie2 = new Cookie("cookie2", data2);
			
			//쿠키 수명 설정
			cookie1.setMaxAge(60);
			cookie2.setMaxAge(60);
			
			//응답정보를 담을 response에 쿠키 정보를 담음
			response.addCookie(cookie1);
			response.addCookie(cookie2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "save_cookie";
	}

	@GetMapping("/load_cookie")
	//Spring에서는 브라우저가 보낸 쿠키정보를 매개변수로 주입받을 수 있다 인코딩,디코딩도 다 되어서 오기때문에 편하다
	public String load_cookie(@CookieValue("cookie1") String cookie1,
							  @CookieValue("cookie2") String cookie2) {
		System.out.println("cookie1 : " + cookie1);
		System.out.println("cookie2 : " + cookie2);
		return "load_cookie"; 
	}
}
