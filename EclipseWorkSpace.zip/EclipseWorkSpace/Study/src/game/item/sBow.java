package game.item;

public class sBow extends Item {
	public int attack;
	public int price;
	public int weight;
	public String color;
 
	public sBow(int attack, int price, int weight, String color) {
		super("활", "작은활");
		this.attack = attack;
		this.price = price;
		this.weight = weight;
		this.color = color;
	}

}
