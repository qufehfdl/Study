package game.item;

public class sSword extends Item {

	public int attack;
	public int price;
	public int weight;
	public String color;

	public sSword(int attack, int price, int weight, String color) {
		super("검", "작은검");
		this.attack = attack;
		this.price = price;
		this.weight = weight;
		this.color = color;
	}
}
