package game.main;

import java.util.Scanner;

public class o2  extends Main{
	@Override
	public String fight() { 
		super.fight();
		System.out.println("축하드립니다2");
		
		System.out.println("무기를 교체하시겠습니까? 네/아니오");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine(); 
		return input;
	}
}
