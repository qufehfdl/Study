package 상속;

class AC extends myProduct {
	public void up() {
		System.out.println("온도를 올립니다");
	}
	public void down() {
		System.out.println("온도를 내립니다");
	}
	
	
	
	public AC(String name, String color, int price, int size) {
		super(name, color, price, size);
	}
	
}
