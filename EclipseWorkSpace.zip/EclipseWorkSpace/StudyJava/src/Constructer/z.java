package Constructer;

public class z {
	z(){
		this(3);
		System.out.println("z의 생성자");
	}
	z(int a){
		System.out.println("z의 int매개변수 생성자");
	}
	
	public static void main(String[] args) {
		x x1 = new x(3);
	}
}

class x extends z{
	x(){
		super();
		System.out.println("x의 생성자");
	}
	x(int a){
		this();
		System.out.println("x의 int매개변수 생성자");
	}
}