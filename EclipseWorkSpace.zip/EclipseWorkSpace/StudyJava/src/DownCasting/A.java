package DownCasting;

public class A {
	String name;
	int age;
	
	A(String name,int age){
		this.name = name;
		this.age = age;
		 
	}
}
