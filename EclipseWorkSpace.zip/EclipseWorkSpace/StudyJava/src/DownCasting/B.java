package DownCasting;

public class B extends A {
	String job;
	int height;

	public B(String job, int height) {
		super("홍태화",32);
		this.job = job;
		this.height = height; 
	}

}
