package DownCasting;

public class C extends B{
	String clothes;
	String color;
	
	public C(String clothes , String color) {
		super("학생",175);
		this.clothes = clothes;
		this.color = color;
	}
}
