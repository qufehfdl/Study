package DownCasting;

public class Main {

	public static void main(String[] args) {
		//업캐스팅은 항상 가능
		
		
		//다운캐스팅
		A a = new B("학생", 175);
		System.out.println(a.name);
		System.out.println(a.age);
//		System.out.println(a.job);			B까지 객체를 만들 수 있지만 A클래스 타입으로 선언했기때문에 
//		System.out.println(a.height);		a는 A클래스를 가리키고 있음
//		System.out.println(a.clothes);
//		System.out.println(a.color);
	
		//#1
		B b = (B) a;						    //a가 B로 다운캐스팅
		System.out.println(b.name);         
		System.out.println(b.age);
		System.out.println(b.job);
		System.out.println(b.height);
//		System.out.println(b.clothes);    	b는 이제 B객체를 가리킬 수 있음
//		System.out.println(b.color);
		
		//#2
		C c = (C) a;
//		System.out.println(c.name);    		a는 처음 객체를 생성할 때 B까지 만들 수 있게했기떄문에 C까지는 다운캐스팅 불가능     
//		System.out.println(c.age);
//		System.out.println(c.job);
//		System.out.println(c.height);
//		System.out.println(c.clothes); 
//		System.out.println(c.color);
		
		//즉 처음 선언할때 어디까지 선언하냐가 중요함
	}

}
