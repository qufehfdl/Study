package ForEach;

import java.util.Vector;

public class Cat {
	int age;
	String name;
	public Cat(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}

	
	public static void main(String[] args) {
		Cat c1 = new Cat(5, "누렁이");
		Cat c2 = new Cat(3, "까망이");

		Vector<Cat> v = new Vector<>();
		
		v.add(c1);
		v.add(c2);
		//객체를 넣을수도 있다 배열특수
		for (Cat x : v) {
			System.out.println(x.age);
			System.out.println(x.name);
		}
	}
}
