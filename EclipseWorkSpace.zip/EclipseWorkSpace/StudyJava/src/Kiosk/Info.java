package Kiosk;

public class Info {
	int ia; //아이스아메리카노
	int ca; //카푸치노
	int cake; //케이크
	int muffin; //머핀

	Info(int a,int b,int c,int d) {
		this.ia = a;
		this.ca = b;
		this.cake = c;
		this.muffin = d; 
	}
	
	public void banner() {
		System.out.println("================================================");
		System.out.println("=================  카페   =======================");
		System.out.println("================================================");
	}
	public static void menuName(String a) {
		System.out.println( a + "가 1개 선택되었습니다");
	}
}
