package Kiosk;

import java.util.Scanner;
import java.util.Vector;

public class Kiosk {

	public void start() {
		// 필드값 초기화
		Info f = new Info(1000, 2000, 3000, 4000);

		// 총 개수,총 금액 구할 객체 선언
		Vector<Integer> vMoney = new Vector<>();
		Vector<Integer> vCount = new Vector<>();

		// 입력받을 객체 선언
		Scanner sc = new Scanner(System.in);
		String cmd;

		// 배너
		f.banner();

		// 진행
		while (true) {

			System.out.println("메뉴 선택 : [ 1.음료 / 2.디저트 / 3.뒤로가기]");
			cmd = sc.next();

			switch (cmd) {

			case "1":
				out1: while (true) {
					System.out.println(" 음료 : [1.아메리카노/2.카푸치노/3.뒤로가기] ");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						Info.menuName("아메리카노");
						vMoney.add(f.ia);
						vCount.add(1);
						break;
					case "2":
						Info.menuName("카푸치노");
						vMoney.add(f.ca); 
						vCount.add(1);
						break;
					case "3":
						System.out.println("뒤로가기");
						break out1;
					}
				}
				break;

			case "2":
				out2: while (true) {
					System.out.println(" 디저트 : [1.케이크/2.머핀/3.뒤로가기] ");
					cmd = sc.next();
					switch (cmd) {
					case "1":
						Info.menuName("케이크");
						vMoney.add(f.cake);
						vCount.add(1);
						break;
					case "2":
						Info.menuName("머핀");
						vMoney.add(f.muffin);
						vCount.add(1);
						break;
					case "3":
						System.out.println("뒤로가기");
						break out2; 
					}
				}
				break;
			}

			// 총금액 합산
			int totalMoney = 0;
			for (int i = 0; i < vMoney.size(); i++) {
				totalMoney = totalMoney + vMoney.get(i);
			}
			System.out.println("상품의 개수 :" + vCount.size() + "개 계산금액은 : " + totalMoney + "원 입니다");
		}
	}
}
