package String;

public class String1 {
	public static void main(String[] args) {
		String cat1 = new String();
		String cat2 = new String();
		
		// 지금 cat1 과 cat2의 stack메모리 주소번지는 서로 다르다
		System.out.println(System.identityHashCode(cat1));
		System.out.println(System.identityHashCode(cat2));
		
		if (cat1==cat2) {
			System.out.println("같다");
		}else {
			System.out.println("다르다");
		}
		
		cat1 = "고양이";
		cat2 = "고양이";
		
		// 지금 cat1 과 cat2의 stack메모리 주소번지는 서로 같다
		System.out.println(System.identityHashCode(cat1));
		System.out.println(System.identityHashCode(cat2));
		
		if (cat1==cat2) {
			System.out.println("같다");
		}else {
			System.out.println("다르다");
		}

	}

}
