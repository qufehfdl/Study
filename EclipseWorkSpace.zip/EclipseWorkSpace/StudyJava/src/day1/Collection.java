package day1;

import java.util.*;

public class Collection {
	public static void main(String[] args) {
		C c1 = new C(3);
		C c2 = new C(3);

		System.out.println(c1 == c2);

		System.out.println(c1.equals(c2));
		System.out.println(c1.hashCode());
		System.out.println(c2.hashCode());

		Set<C> h = new HashSet<>();

		h.add(c1);
		h.add(c2);
		System.out.println(h.size()); // 1 : 같은객체임
	}
}

class C {

	int data;

	// int타입 정수를 매개변수로받아서 필드에 반환해주는 코드
	public C(int data) {
		this.data = data;
	}

	// 필드값이 같으면 해쉬코드를 같게하라는 코드
	public int hashCode() {
		return data;
	}

	// 이퀄스 메서드를 오버라이딩
	public boolean equals(Object obj) {
		if (obj instanceof C) {
			if (this.data == ((C) obj).data)
				;
		}
		return true;
	}

}
