package day1;
import java.util.*;

//나의 중복없는 랜덤 번호
class myNum {
	public static Integer[] my() {
		TreeSet<Integer> my = new TreeSet<>();
		while (my.size() < 6) {
			int v1 = (int) (Math.random() * 45) + 1;
			my.add(v1);
		} 
		Integer[] integers = my.toArray(new Integer[0]);
		//[11]과[13~14는 같다]
//		Object[] i = my.toArray();
//		Integer[] a = (Integer[]) i;
		
		System.out.println("나의 번호 : " + Arrays.toString(integers));
		return integers;
	}
}

//컴퓨터의 중복없는 랜덤 번호
class comNum {
	public static Integer[] com() {
		TreeSet<Integer> com = new TreeSet<>();
		while (com.size() < 6) {
			int v1 = (int) (Math.random() * 45) + 1;
			com.add(v1);
		}
		Integer[] integers = com.toArray(new Integer[0]);
		System.out.println("컴퓨터 번호 : " + Arrays.toString(integers));
		return integers;
	}
}

//결과 클래스
class check {

	// 맞은 갯수 확인
	public static void myCheck(Integer[] a, Integer[] b) {
		int win = 0;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				if (a[i] == b[j]) {
					win = win + 1;
				}
			}
		}

		// 보너스번호가 컴퓨터번호와 중복인지 체크
		int bonus = (int) (Math.random() * 45) + 1;
		out: while (true) {
			bonus = (int) (Math.random() * 45) + 1;
			if (bonus == b[0]) {
				continue;
			} else if (bonus == b[1]) {
				continue;
			} else if (bonus == b[3]) {
				continue;
			} else if (bonus == b[4]) {
				continue;
			} else if (bonus == b[5]) {
				continue;
			} else {
				break out;
			}
		}

		// 컴퓨터 번호와 중복이 없는 보너스 번호
		System.out.println("보너스 넘버 : " + bonus);

		//등수 확인
		String twoAndThree = "";
		switch (win) {
		case 0:
		case 1:
		case 2:
			twoAndThree = "꽝입니다";
			break;
		case 3:
			twoAndThree = "5등입니다";
			break;
		case 4:
			twoAndThree = "4등입니다";
			break;
		case 5:
			twoAndThree = "3등입니다";
			for (int k = 0; k < 6; k++) {
				if (win == 5 && a[k] == bonus) {
					twoAndThree = "2등입니다";
					break;
				}
			}
			break;
		case 6:
			twoAndThree = "1등입니다";
			break;
		}
		System.out.println(twoAndThree);
	}
}

//실행
public class Lotto {
	public static void main(String[] args) {
		check.myCheck(myNum.my(),comNum.com());
	}
}
