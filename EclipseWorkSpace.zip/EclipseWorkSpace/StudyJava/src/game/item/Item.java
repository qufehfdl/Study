package game.item;

public class Item {
	public String category;
	public String name;

	Item(String category, String name) {
		this.name = name;
		this.category = category;

	}
}
