package game.item;

public class lBow extends Item {
	public int attack;
	public int price;
	public int weight;
	public String color;

	public lBow(int attack, int price, int weight, String color) {
		super("활", "큰활");
		this.attack = attack;
		this.price = price;
		this.weight = weight;
		this.color = color;
	}

}
