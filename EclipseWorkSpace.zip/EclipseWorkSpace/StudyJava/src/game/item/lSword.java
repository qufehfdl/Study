package game.item;

public class lSword extends Item {
	public int attack;
	public int price;
	public int weight;
	public String color;
	
	public lSword(int attack, int price, int weight, String color) {
		super("검", "큰검");
		this.attack = attack;
		this.price = price;
		this.weight = weight;
		this.color = color;
	}
}
