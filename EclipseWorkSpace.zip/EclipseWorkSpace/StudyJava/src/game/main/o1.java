package game.main;

public class o1 extends Main{
	@Override
	public String fight() {
		super.fight();
		System.out.println("축하드립니다1");
		
		return "";
	}
}
