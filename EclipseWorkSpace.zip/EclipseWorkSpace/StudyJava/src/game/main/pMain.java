package game.main;

import game.item.lBow;
import game.item.lSword;
import game.item.sBow;
import game.item.sSword;
import game.player.Monster;
import game.player.Player;

public class pMain {
	lSword s1 = new lSword(20, 2000, 100, "검정");
	sSword s2 = new sSword(10, 1000, 50, "하얀색");
	lBow b1 = new lBow(15, 1500, 75, "빨강");
	sBow b2 = new sBow(5, 500, 25, "노랑");

	Monster m = new Monster(s1.name, s1.attack);
	Player p = new Player(s2.name, s2.attack);

	public void fight() {
		int mDown = m.hp;
		int pDown = p.hp;

		while (true) {
			int a = (int) (Math.random() * 2 + 1);
			if (a == 1) {
				pDown = pDown - m.totalAttack;
				System.out.println(m.name + "가 공격하여" + m.totalAttack + "의 피해를 주었습니다 " + p.name + "의 남은체력은" + pDown);
			} else {
				mDown = mDown - p.totalAttack;
				System.out.println(p.name + "가 공격하여" + p.totalAttack + "의 피해를 주었습니다 " + m.name + "의 남은체력은" + mDown);
			}
			if (pDown < 1) {
				System.out.println("몬스터 승리 전투종료");
				break;
			}
			if (mDown < 1) {
				System.out.println("플레이어 승리 전투종료");
				break;}}
	
	}

	public static void main(String[] args) {
		pMain ma = new pMain();
		ma.fight();
	}
}
