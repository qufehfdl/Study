package game.player;

import game.item.lSword;

public class Monster extends pObject {
	public String weapon;
	public int wAttack;
	public int totalAttack;

	public Monster(String weapon, int wAttack) {
		super("나쁜애", 200, 30);
		this.weapon = weapon;
		this.wAttack = wAttack; 
		this.totalAttack = super.attack + wAttack;
		
		System.out.println("몬스터가 " + weapon + "을 장착! 몬스터의 총공격력은 :" + totalAttack);
	}
}
