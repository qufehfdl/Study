package game.player;

import game.item.sSword;

public class Player extends pObject {
	public String weapon;
	public int wAttack;
	public int totalAttack;

	public Player(String weapon, int wAttack) {
		super("태화", 190, 20);
		this.weapon = weapon;
		this.wAttack = wAttack;
		this.totalAttack = super.attack + wAttack;

		System.out.println("플레이어가 " + weapon + "을 장착! 플레이어의 총공격력은 :" + totalAttack);
	}
}
