package game.player;

public class pObject {
	public String name;
	public int hp;
	public int attack;

	public pObject(String name, int hp, int attack) {
		this.name = name;
		this.hp = hp;
		this.attack = attack;
	}
}
