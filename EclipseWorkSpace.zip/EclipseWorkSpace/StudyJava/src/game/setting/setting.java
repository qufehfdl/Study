package game.setting;

import game.item.lBow;
import game.item.lSword;
import game.item.sBow;
import game.item.sSword;
import game.main.o2;
import game.player.Monster;
import game.player.Player;

public class setting {
	lSword s1 = new lSword(20, 2000, 100, "검정");
	sSword s2 = new sSword(10, 1000, 50, "하얀색");
	lBow b1 = new lBow(15, 1500, 75, "빨강");
	sBow b2 = new sBow(5, 500, 25, "노랑");

	public void cg(String sp) {
		o2 a = new o2();
		String str = "네";
		if (str.equals(sp)) {
			Monster m = new Monster(b1.name, b1.attack);
			Player p = new Player(b2.name, b2.attack);

			System.out.println("몬스터가 무기를 " + b1.name + "으로 교체합니다 총공격력 :" + m.totalAttack);
			System.out.println("플레이어가 무기를 " + b2.name + "으로 교체합니다 총공격력 :" + p.totalAttack);
			System.out.println("전투를 다시 시작합니다");
a.fight();
		}
	}
}
