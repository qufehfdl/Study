package 상속;

public class Example {

	public static void main(String[] args) {
		TV tv = new TV("싼티비", "black", 10000, 10,5);
		System.out.println(tv.price);
		System.out.println(tv.color);
		System.out.println(tv.size);
		System.out.println(tv.remotePrice);
		tv.on();
		tv.Channel();
		tv.off();
		TV tv2 = new TV("비싼티비", "white", 1000000, 30,5);
		System.out.println(tv2.price);
		System.out.println(tv2.color);
		System.out.println(tv2.size);
		System.out.println(tv2.remotePrice);
		tv2.on();
		tv2.Channel();
		tv2.off();
		
		AC ac = new AC("싼에어컨","red",2000,20);
		System.out.println(ac.name);
		ac.up();
	}

}
