package 상속;

class TV extends myProduct {
	int remotePrice;

	public TV(String name, String color, int price, int size, int remotePrice) {
		super(name, color, price, size);
		this.remotePrice = remotePrice;
	}

	public void Channel() {
		System.out.println("채널을 돌립니다");
	}
}
