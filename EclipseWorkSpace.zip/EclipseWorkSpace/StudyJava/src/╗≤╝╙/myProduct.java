package 상속;

public class myProduct {
	String name;
	String color;
	int price;
	int size;

	public myProduct(String name, String color, int price, int size) {
		this.name = name;
		this.color = color;
		this.price = price;
		this.size = size;
	}

	public void on() {
		System.out.println("전원을 킵니다");
	}

	public void off() {
		System.out.println("전원을 끕니다");
	}
}
