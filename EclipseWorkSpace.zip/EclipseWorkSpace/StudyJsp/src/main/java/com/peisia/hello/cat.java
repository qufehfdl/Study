package com.peisia.hello;

public class cat {
	public String name = "야옹이";
}
