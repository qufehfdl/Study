package Controller.Main;

import java.io.IOException;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.BoardBean;
import Model.BoardDAO;
 
@WebServlet("/Search.do")
public class Search extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		req(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		req(request, response);
	}

	protected void req(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("asd");
		String s = request.getParameter("search");
		
		BoardDAO dao = new BoardDAO(); 
		Vector<BoardBean> v = dao.search(s);
		request.setAttribute("v", v);
		request.setAttribute("id", id);
		RequestDispatcher dis = request.getRequestDispatcher("Search.jsp");
		dis.forward(request, response);
	}

}
