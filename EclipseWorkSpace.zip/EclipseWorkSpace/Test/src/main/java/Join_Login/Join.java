package Join_Login;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.MemberBean;
import Model.MemberDAO;
 
@WebServlet("/Join.do")
public class Join extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		reqPro(request, response);
	}

	protected void reqPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String id = request.getParameter("id");
		String pw1 = request.getParameter("pw1");
		String pw2 = request.getParameter("pw2");
		String email = request.getParameter("email");
		String tel = request.getParameter("tel");

		request.getParameter("save");

		if (pw1.equals(pw2)) {
			MemberDAO mdao = new MemberDAO();
			MemberBean mbean = new MemberBean();
			mbean.setId(id);
			mbean.setPw(pw1);
			mbean.setEmail(email);
			mbean.setTel(tel);
			mdao.insertMember(mbean);
			RequestDispatcher dis = request.getRequestDispatcher("Login.jsp");
			dis.forward(request, response);
			
		}else {
			response.sendRedirect("JoinError.jsp");
		}

	}
}
