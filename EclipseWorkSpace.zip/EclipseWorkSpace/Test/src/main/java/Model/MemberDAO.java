package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MemberDAO {
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public void getCon() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/taehwa", "root", "1042");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 회원가입 정보를 멤버테이블에 넣음
	public void insertMember(MemberBean b) {
		getCon();
		try {
			String sql = "insert into member(id,pw,email,tel) values(?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, b.getId());
			pstmt.setString(2, b.getPw());
			pstmt.setString(3, b.getEmail());
			pstmt.setString(4, b.getTel());
			pstmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 로그인 하기위해 id,pw를 리턴받아 확인
	public MemberBean check(String id) {
		getCon();
		MemberBean mBean = new MemberBean();
		try {
			String sql = "select id,pw from member where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				mBean.setId(rs.getString(1));
				mBean.setPw(rs.getString(2));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mBean;
	}
}
