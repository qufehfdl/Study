package testPjt;
 
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		//자바형식
//		TranspotationWalk transpotationWalk = new TranspotationWalk();
//		transpotationWalk.move();

		//스프링 컨테이너 접근
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationContext.xml");
		//컨테이너안에있는 객체 Bean을 가져와서 t에 넣어줌
		TranspotationWalk t = ctx.getBean("tWalk",TranspotationWalk.class);
		
		t.move();
		//리소스 반환
		ctx.close(); 
	}

}
