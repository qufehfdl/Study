package testPjt;

public class TranspotationWalk {
public void move() {
	System.out.println("도보로 이동합니다");
}
}
