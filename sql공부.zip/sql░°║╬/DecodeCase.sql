--값에 따라 반환값이 결정되는 구문
SELECT COMPANY ,DECODE(COMPANY ,'현대','현대차'
											,'쌍용','쌍용차'
											,'삼성','삼성차')
FROM JSP.RENTCAR ;

SELECT PRICE  ,DECODE(PRICE,2002,PRICE*1.2)
FROM JSP.RENTCAR ;

--조건에 따라 반환값이 결정되는 구문

SELECT NAME,CATEGORY ,		CASE when CATEGORY = 1 THEN '카테고리 1차'
												  WHEN CATEGORY = 2 THEN '카테고리 2차'
												  ELSE '차'
END 
FROM JSP.RENTCAR ;