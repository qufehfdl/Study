--그룹바이절을 사용하면 SELECT으로 얻어온 결과를 정해진 기준에 따라 그룹을 분류하고
--각 그룹내에서 그룹함수를 사용할 수 있다

--각 회사별 price의 평균값을 구한다
SELECT COMPANY ,AVG(PRICE) 
FROM JSP.RENTCAR 
GROUP BY COMPANY ;
--각 카테고리별 price의 평균을 구한다
SELECT CATEGORY  ,AVG(PRICE) 
FROM JSP.RENTCAR 
GROUP BY CATEGORY ;

-- 회사가 현대인 각 카테고리별 price의 평균값을 구한다
SELECT CATEGORY  ,AVG(PRICE) 
FROM JSP.RENTCAR 
WHERE COMPANY ='현대'
GROUP BY CATEGORY ;

--2000원 초과인 회사별 가격의 평균값을 구한다
SELECT COMPANY ,AVG(PRICE) 
FROM JSP.RENTCAR 
WHERE PRICE >2000 
GROUP BY COMPANY; 

--2000원 초과이면서 카테고리가 1인 회사별 가격의 평균값
SELECT COMPANY ,AVG(PRICE) 
FROM JSP.RENTCAR 
WHERE PRICE >2000 AND CATEGORY =1
GROUP BY COMPANY; 

