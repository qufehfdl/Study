--그룹바이로 묶인 각 그룹들 중에 실제 가져올 그룹을 선택하는 조건을 having에 작성
--where은 SELECT 으로 가져온 로우(가로)에 대한 조건
--HAVING GROUP BY 에 대한 조건

--PRICE 의 평균값이 2003이상인 회사들의 차 가격 총 합
SELECT COMPANY , SUM(PRICE) 
FROM JSP.RENTCAR 
GROUP BY COMPANY 
HAVING AVG(PRICE)>=2003 ; 

--price의 최대값이 2007이하인 회사들의 차 가격 총 합
SELECT COMPANY , SUM(PRICE) 
FROM JSP.RENTCAR 
GROUP BY COMPANY 
HAVING MAX(PRICE)<=2007 ; 

--최소가격이 2002이하인 회사들의의 카테고리가 1인 차량가격의 총 합
SELECT COMPANY , SUM(PRICE) 
FROM JSP.RENTCAR 
WHERE CATEGORY =1
GROUP BY COMPANY 
HAVING MIN(PRICE)<=2002  
ORDER BY SUM(PRICE) DESC  ;