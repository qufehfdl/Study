--1.다음과 같은 사원정보를 추가한다
--1111 홍길동 인사
--2222 김길동 개발
--3333 최길동 인사
--4444 박길동 생산

INSERT INTO EMP1 (EMPNO,ENAME,JOB)
VALUES (1111,'홍길동','인사');
INSERT INTO EMP1 (EMPNO,ENAME,JOB)
VALUES (2222,'김길동','개발');
INSERT INTO EMP1 (EMPNO,ENAME,JOB)
VALUES (3333,'최길동','인사');
INSERT INTO EMP1 (EMPNO,ENAME,JOB)
VALUES (4444,'박길동','생산');

--2.컬럼목록을 생략하는 경우
--단 모든컬럼에 데이터를 집어넣는 경우만
INSERT INTO EMP1
VALUES (5555,'황길동','개발');

--3.컬럼목록에 모든 컬럼이 있지 않은 경우
--NULL이 저장이 된다
INSERT INTO EMP1 (EMPNO,ENAME)
VALUES (6666,'임길동');

--4.NULL을 명시적 저장
INSERT INTO EMP1 (EMPNO,ENAME,JOB)
VALUES (7777,'길동',NULL);

--구조만 복사하는 쿼리
CREATE TABLE EMP02
AS
SELECT EMPNO,ENAME,JOB FROM EMP WHERE 1=0;
--복사한 구조에 데이터 넣음
INSERT INTO EMP2 (EMPNO,ENAME,JOB)
SELECT EMPNO ,ENAME,JOB FROM EMP;
--똑같은 구조를 가진 테이블(EMP1) 을 컬럼목록생략하여 데이터 넣음
INSERT INTO EMP2 
SELECT EMPNO ,ENAME,JOB FROM EMP1;


















SELECT * FROM EMP2 ;
