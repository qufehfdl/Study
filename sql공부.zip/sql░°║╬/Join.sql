SELECT * FROM EMP ,DEPT ;
--두개 이상의 테이블에서 가져온 결과 중 정확한 결과만 가져오기 위해 
-- ㅇ공통부분ㅇ을 이용한 조건문이 반드시 필요하다

--조인시에는 as가 필요
SELECT * FROM EMP a1 ,DEPT a2
WHERE a1.DEPTNO = a2.DEPTNO ;

--사원의 사원번호 ,이름 ,근무부서이름을 가져온다
SELECT a1.EMPNO ,a1.ENAME , a2.DNAME 
FROM  EMP a1,DEPT a2
WHERE a1.DEPTNO  = a2.DEPTNO  ;

--사원의 사원번호,이름,근무지역을 가져온다
SELECT a1.EMPNO  ,a1.ENAME  , a2.LOC  
FROM EMP a1,DEPT a2
WHERE a1.DEPTNO = a2.DEPTNO  ;

--dallas에 근무하는 사원들의 사원번호 이름 직무를 가져온다
SELECT a1.EMPNO ,a1.ENAME ,a1.JOB 
FROM EMP a1,DEPT a2
WHERE a1.DEPTNO = a2.DEPTNO AND a2.LOC = 'DALLAS';

--세일즈 부서에 근무하는 사원들의 급여 평균
SELECT TRUNC(AVG(a1.SAL)) 
FROM EMP a1 , DEPT a2
WHERE a1.DEPTNO =a2.DEPTNO AND a2.DNAME ='SALES';

--1982년에 입사한 사원들의 사원번호 이름 입사일 근무부서이름을 가져온다
SELECT a1.EMPNO ,a1.ENAME ,a1.HIREDATE ,a2.DNAME  
FROM EMP a1,DEPT a2
WHERE a1.DEPTNO = a2.DEPTNO AND a1.HIREDATE BETWEEN '1982/01/01' AND '1982/12/31';

--각 사원들의 사원번호 이름 급여 급여등급을 가져온다
SELECT a1.EMPNO ,a1.ENAME ,a1.SAL ,a2.GRADE 
FROM EMP a1 ,SALGRADE a2
WHERE a1.SAL BETWEEN a2.LOSAL AND a2.HISAL; 

--sales 부서에 근무하고있는 사원의 사원번호 이름 급여등급을 가져온다
SELECT a1.EMPNO ,a1.ENAME ,a1.SAL ,a2.GRADE 
FROM EMP a1 ,SALGRADE a2 ,DEPT a3
WHERE a1.SAL BETWEEN a2.LOSAL AND a2.HISAL AND a1.DEPTNO =a3.DEPTNO 
						AND a3.DNAME ='SALES';
						
--급여등급이 4등급인 사원들의 사원번호 이름 급여 근무부서이름 근무지역을 가져온다
SELECT A1.EMPNO ,A1.ENAME ,A1.SAL ,A2.DNAME ,A2.LOC 
FROM EMP A1,DEPT A2,SALGRADE A3
WHERE A1.SAL BETWEEN A3.LOSAL AND A3.HISAL AND A1.DEPTNO =A2.DEPTNO 
						AND A3.GRADE = '4';

	