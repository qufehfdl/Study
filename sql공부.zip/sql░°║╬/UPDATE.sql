CREATE TABLE EMP3
AS
SELECT * FROM EMP ;

--사원들의 부서 번호를 40번으로 저장
UPDATE EMP03
SET DEPTNO=40;

--사원들의 입사일을 오늘로 변경
UPDATE  EMP03 
SET HIREDATE =SYSDATE ;

--사원들의 직무로 개발자로 변경
UPDATE  EMP03 
SET JOB ='DEVELOPER';

CREATE TABLE EMP4
AS
SELECT * FROM EMP ;

--사원들의 부서번호를 40 ,입사일을 오늘 ,직무를 개발자로 변경
UPDATE EMP4
SET DEPTNO=40,HIREDATE=SYSDATE,JOB='DEVELOPER';

--WHERE이 없으면 모든 로우에대해서 해당컬럼이 다 바뀜
--10번 부서에 근무하고있는 사원들의 40번 부서로 수정
UPDATE EMP3
SET DEPTNO=40
WHERE DEPTNO=10;

--전체 사원의 평균급여보다 낮은 사원들의 급여를 50%인상한다
UPDATE EMP3
SET SAL=SAL*1.5
WHERE SAL<(SELECT AVG(SAL) FROM EMP3);


SELECT * FROM EMP3;
SELECT * FROM EMP4;
