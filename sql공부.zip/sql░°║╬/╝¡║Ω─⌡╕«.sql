--ㅇ서브쿼리ㅇ

--SCOTT사원이 근무하고 있는 부서의 이름을 가져온다
SELECT DNAME 
FROM DEPT  
WHERE DEPTNO = (SELECT DEPTNO FROM EMP WHERE ENAME='SMITH' );


--SMITH와 같은 부서에 근무하고 있는 사원들의 사원번호/이름/급여액/부서이름을 가져온다
SELECT  A1.EMPNO ,A1.ENAME ,A1.SAL ,A2.DNAME 
FROM EMP A1,DEPT A2
WHERE A1.DEPTNO =A2.DEPTNO AND A1.DEPTNO =
(SELECT DEPTNO  FROM EMP  WHERE ENAME ='SMITH' );

--MARTIN과 같은 직무를 가진 사원들의 사원번호/이름/직무를 가져온다
SELECT EMPNO ,ENAME ,JOB 
FROM EMP 
WHERE JOB = (SELECT JOB FROM EMP WHERE ENAME='MARTIN');

--SALESMAN의 평균급여보다 많이받는 사원들의 사원번호/이름/급여를 가져온다
SELECT EMPNO ,ENAME ,SAL 
FROM EMP 
WHERE  SAL>(SELECT AVG(SAL) FROM EMP  WHERE JOB='SALESMAN');


--ㅇ결과가 하나이상인 서브쿼리ㅇ
--1 IN은 서브쿼리의 결과중 하나라도 일치하면 조건은 참이됨
--2 ANY,SOME은 서브쿼리 결과와 하나이상 일치하면 조건은 참이됨   
--3 ALL은 서브쿼리의 결과와 모두 일치해야 조건은 참이됨              

--3000이상의 급여를 받는 사원들과 같은 부서에 근무하고 있는 사원의 사원번호/이름/급여를 가져온다
SELECT EMPNO ,ENAME ,SAL 
FROM EMP 
WHERE DEPTNO IN (SELECT DEPTNO 
								FROM EMP 
								WHERE SAL>=3000);

--각 부서별 급여 평균보다 더 많이 받는 사원의 사원번호/이름/급여를 가져온다
SELECT EMPNO ,ENAME ,SAL 
FROM EMP 
WHERE SAL>ALL(SELECT AVG(SAL) 
							FROM EMP 
							GROUP BY DEPTNO);

SELECT EMPNO ,ENAME ,SAL 
FROM EMP 
WHERE SAL>(SELECT MAX(AVG(SAL))
							FROM EMP 
							GROUP BY DEPTNO);